-- Create table for bump photos
CREATE TABLE IF NOT EXISTS bump_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  photo_url TEXT NOT NULL,
  week_number INTEGER NOT NULL,
  captured_at TIMESTAMP WITH TIME ZONE NOT NULL,
  alignment_data JSONB, -- Stores alignment data like face position, grid offsets, etc.
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable real-time updates for this table
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE bump_photos;
EXCEPTION
    WHEN duplicate_object THEN
        NULL;
END $$;

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_bump_photos_user_id ON bump_photos(user_id);
CREATE INDEX IF NOT EXISTS idx_bump_photos_week_number ON bump_photos(week_number);
CREATE INDEX IF NOT EXISTS idx_bump_photos_captured_at ON bump_photos(captured_at);

-- Create table for generated bump videos
CREATE TABLE IF NOT EXISTS bump_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  video_url TEXT NOT NULL,
  photo_count INTEGER NOT NULL,
  weeks_covered JSONB, -- Stores range of weeks covered: {start_week: X, end_week: Y}
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable real-time updates for this table
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE bump_videos;
EXCEPTION
    WHEN duplicate_object THEN
        NULL;
END $$;

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_bump_videos_user_id ON bump_videos(user_id);
CREATE INDEX IF NOT EXISTS idx_bump_videos_created_at ON bump_videos(created_at);
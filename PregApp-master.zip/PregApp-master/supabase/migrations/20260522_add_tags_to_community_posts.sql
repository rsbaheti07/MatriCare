-- Add tags column to community_posts table
ALTER TABLE community_posts
ADD COLUMN IF NOT EXISTS tags TEXT[];

-- Create index for better query performance on tags array
CREATE INDEX IF NOT EXISTS idx_community_posts_tags ON community_posts USING GIN (tags);

-- Optional: Create a function to get all unique tags used in posts
-- This can be useful for admin panels or tag suggestions
CREATE OR REPLACE FUNCTION get_all_community_post_tags()
RETURNS TABLE (tag TEXT, usage_count INTEGER) AS $$
    SELECT
        unnest(tags) as tag,
        COUNT(*) as usage_count
    FROM community_posts
    WHERE tags IS NOT NULL AND array_length(tags, 1) > 0
    GROUP BY unnest(tags)
    ORDER BY usage_count DESC;
$$ LANGUAGE SQL;
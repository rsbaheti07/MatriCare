-- Create table for user's hospital checklist state and custom items
CREATE TABLE IF NOT EXISTS user_hospital_checklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  item_id TEXT NOT NULL, -- For predefined items, this is the id from the static list (e.g., 'mom-1'). For custom items, we generate a UUID.
  is_custom BOOLEAN NOT NULL DEFAULT FALSE,
  is_packed BOOLEAN NOT NULL DEFAULT FALSE,
  custom_description TEXT, -- Override description for predefined items, or description for custom items
  category TEXT NOT NULL, -- Stored for convenience to avoid joining with static list
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable real-time updates for this table
alter publication supabase_realtime add table user_hospital_checklist;

-- Create index for faster queries by user
CREATE INDEX IF NOT EXISTS idx_user_hospital_checklist_user_id ON user_hospital_checklist(user_id);

-- Create index for faster queries by item (for predefined items)
CREATE INDEX IF NOT EXISTS idx_user_hospital_checklist_item_id ON user_hospital_checklist(item_id) WHERE NOT is_custom;

-- Create index for custom items
CREATE INDEX IF NOT EXISTS idx_user_hospital_checklist_is_custom ON user_hospital_checklist(is_custom) WHERE is_custom;
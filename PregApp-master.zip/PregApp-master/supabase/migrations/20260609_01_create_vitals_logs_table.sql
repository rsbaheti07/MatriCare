-- Create vitals_logs table for storing user vital measurements
CREATE TABLE IF NOT EXISTS vitals_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  systolic_bp INTEGER,
  diastolic_bp INTEGER,
  weight_kg REAL,
  blood_sugar_mgdl REAL,
  logged_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable real-time updates for this table
alter publication supabase_realtime add table vitals_logs;

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_vitals_logs_user_id ON vitals_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_vitals_logs_logged_at ON vitals_logs(logged_at);
CREATE INDEX IF NOT EXISTS idx_vitals_logs_created_at ON vitals_logs(created_at);
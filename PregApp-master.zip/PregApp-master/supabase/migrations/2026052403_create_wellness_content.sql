-- Create table for wellness content (articles, videos, etc.)
CREATE TABLE IF NOT EXISTS wellness_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  category TEXT NOT NULL, -- Sleep, Diet, Exercise, Mindfulness
  content_type TEXT NOT NULL, -- Article, Video, Audio, Infographic
  content_body TEXT, -- For articles, the main content (could be HTML or markdown)
  summary TEXT, -- Short summary for preview
  url TEXT, -- External link if the content is hosted elsewhere
  duration_minutes INTEGER, -- For video/audio content
  trimester_relevance TEXT[], -- Array of trimesters: ['first', 'second', 'third', 'postpartum', 'any']
  difficulty_level TEXT, -- Beginner, Intermediate, Advanced
  published_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  -- Optional: metrics for popularity
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0
);

-- Enable real-time updates for this table
alter publication supabase_realtime add table wellness_content;

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_wellness_content_category ON wellness_content(category);
CREATE INDEX IF NOT EXISTS idx_wellness_content_content_type ON wellness_content(content_type);
CREATE INDEX IF NOT EXISTS idx_wellness_content_trimester ON wellness_content USING GIN (trimester_relevance);
CREATE INDEX IF NOT EXISTS idx_wellness_content_difficulty ON wellness_content(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_wellness_content_published ON wellness_content(published_at);

-- Create table for user's bookmarked wellness content
CREATE TABLE IF NOT EXISTS user_wellness_bookmarks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  wellness_content_id UUID REFERENCES wellness_content(id) ON DELETE CASCADE,
  bookmarked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, wellness_content_id)
);

-- Enable real-time updates for this table
alter publication supabase_realtime add table user_wellness_bookmarks;

-- Create index for faster queries by user
CREATE INDEX IF NOT EXISTS idx_user_wellness_bookmarks_user_id ON user_wellness_bookmarks(user_id);

-- Create index for faster queries by content
CREATE INDEX IF NOT EXISTS idx_user_wellness_bookmarks_wellness_content_id ON user_wellness_bookmarks(wellness_content_id);
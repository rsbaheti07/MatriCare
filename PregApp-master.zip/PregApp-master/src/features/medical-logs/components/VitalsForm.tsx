'use client';

import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label'; // We'll need to create this
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast'; // We'll create this hook

// Since we don't have a Label component yet, let's create a simple one or use a div with proper styling
// For now, we'll use a div with the label styling and create the Label component later if needed
// But let's create it now to keep things clean

export const VitalsForm = () => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm({
    defaultValues: {
      systolic: '',
      diastolic: '',
      weight: '',
      bloodSugar: '',
      date: new Date().toISOString().split('T')[0],
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      if (!user) throw new Error('User not authenticated');
      const { data: result, error } = await supabase
        .from('vitals_logs')
        .insert({
          user_id: user.id,
          systolic_bp: data.systolic ? parseInt(data.systolic) : null,
          diastolic_bp: data.diastolic ? parseInt(data.diastolic) : null,
          weight_kg: data.weight ? parseFloat(data.weight) : null,
          blood_sugar_mgdl: data.bloodSugar ? parseFloat(data.bloodSugar) : null,
          logged_at: data.date,
        });

      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vitals'] });
      toast({
        title: 'Vitals logged successfully',
        description: 'Your vitals have been saved.',
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error logging vitals',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    mutation.mutate(data);
  });

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <div className="text-sm font-medium text-muted-foreground">Systolic BP (mmHg)</div>
          <Input
            type="number"
            placeholder="e.g., 120"
            {...form.register('systolic', {
              validate: (value) => {
                const num = parseInt(value);
                return !value || (num >= 80 && num <= 250) || 'Please enter a valid systolic BP';
              },
            })}
          />
          {form.formState.errors.systolic && (
            <p className="text-sm text-destructive">{form.formState.errors.systolic.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <div className="text-sm font-medium text-muted-foreground">Diastolic BP (mmHg)</div>
          <Input
            type="number"
            placeholder="e.g., 80"
            {...form.register('diastolic', {
              validate: (value) => {
                const num = parseInt(value);
                return !value || (num >= 50 && num <= 150) || 'Please enter a valid diastolic BP';
              },
            })}
          />
          {form.formState.errors.diastolic && (
            <p className="text-sm text-destructive">{form.formState.errors.diastolic.message}</p>
          )}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <div className="text-sm font-medium text-muted-foreground">Weight (kg)</div>
          <Input
            type="number"
            step="0.1"
            placeholder="e.g., 65.5"
            {...form.register('weight', {
              validate: (value) => {
                const num = parseFloat(value);
                return !value || (num >= 30 && num <= 200) || 'Please enter a valid weight';
              },
            })}
          />
          {form.formState.errors.weight && (
            <p className="text-sm text-destructive">{form.formState.errors.weight.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <div className="text-sm font-medium text-muted-foreground">Blood Sugar (mg/dL)</div>
          <Input
            type="number"
            step="0.1"
            placeholder="e.g., 90.5"
            {...form.register('bloodSugar', {
              validate: (value) => {
                const num = parseFloat(value);
                return !value || (num >= 50 && num <= 300) || 'Please enter a valid blood sugar level';
              },
            })}
          />
          {form.formState.errors.bloodSugar && (
            <p className="text-sm text-destructive">{form.formState.errors.bloodSugar.message}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-sm font-medium text-muted-foreground">Date</div>
        <Input
          type="date"
          defaultValue={new Date().toISOString().split('T')[0]}
          {...form.register('date')}
        />
      </div>

      <Button
        type="submit"
        disabled={mutation.isPending}
        className="w-full"
      >
        {mutation.isPending ? 'Logging...' : 'Log Vitals'}
      </Button>
    </form>
  );
};
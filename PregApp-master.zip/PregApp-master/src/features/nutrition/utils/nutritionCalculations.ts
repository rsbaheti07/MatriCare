// Nutrition recommendations based on pregnancy week and dietary type
// This is a simplified rules engine. In a real app, this would be more comprehensive and possibly sourced from a database or external API.

export type DietaryType = 'veg' | 'non-veg' | 'jain';

// Weeks of pregnancy are typically grouped into trimesters:
// First trimester: weeks 1-12
// Second trimester: weeks 13-27
// Third trimester: weeks 28-40+

// We'll create a function that returns nutrition recommendations for a given week and dietary type.
export const getNutritionRecommendations = (week: number, dietaryType: DietaryType) => {
  // Adjust week to be within 1-40 for calculation purposes (clamp)
  const clampedWeek = Math.min(Math.max(week, 1), 40);

  // Base recommendations that are common for all dietary types
  const baseRecommendations = {
    calories: {
      firstTrimester: 1800, // Approximate, will adjust by week
      secondTrimester: 2200,
      thirdTrimester: 2400,
    },
    protein: {
      firstTrimester: 46, // grams
      secondTrimester: 71,
      thirdTrimester: 71,
    },
    calcium: {
      firstTrimester: 1000, // mg
      secondTrimester: 1000,
      thirdTrimester: 1000,
    },
    iron: {
      firstTrimester: 27, // mg
      secondTrimester: 27,
      thirdTrimester: 27,
    },
    folicAcid: {
      firstTrimester: 600, // mcg
      secondTrimester: 600,
      thirdTrimester: 600,
    },
    // We'll also consider common pregnancy discomforts and suggest foods to help
  };

  // Adjust calories by week (simplified linear increase)
  let calories = 0;
  if (clampedWeek <= 12) {
    // First trimester: slight increase
    calories = baseRecommendations.calories.firstTrimester + (clampedWeek - 1) * 10;
  } else if (clampedWeek <= 27) {
    // Second trimester
    calories = baseRecommendations.calories.secondTrimester + (clampedWeek - 13) * 15;
  } else {
    // Third trimester
    calories = baseRecommendations.calories.thirdTrimester + (clampedWeek - 28) * 10;
  }

  // Adjust protein needs (more in second and third trimester)
  let protein = baseRecommendations.protein.firstTrimester;
  if (clampedWeek > 12) {
    protein = baseRecommendations.protein.secondTrimester;
  }
  if (clampedWeek > 27) {
    protein = baseRecommendations.protein.thirdTrimester;
  }

  // Other nutrients remain relatively stable, but we can adjust slightly if needed
  const calcium = baseRecommendations.calories.firstTrimester;
  const iron = baseRecommendations.iron.firstTrimester;
  const folicAcid = baseRecommendations.folicAcid.firstTrimester;

  // Dietary-specific adjustments
  let proteinSources: string[] = [];
  let ironSources: string[] = [];
  let calciumSources: string[] = [];
  let folicAcidSources: string[] = [];

  switch (dietaryType) {
    case 'non-veg':
      proteinSources = ['Chicken, fish, eggs, lean meat', 'Legumes and lentils', 'Dairy or alternatives'];
      ironSources = ['Red meat, poultry, fish', 'Legumes, tofu, fortified cereals (with vitamin C for absorption)'];
      calciumSources = ['Dairy products (milk, yogurt, cheese)', 'Fortified plant-based milks', 'Leafy greens'];
      folicAcidSources = ['Leafy greens (spinach, kale)', 'Legumes', 'Fortified grains', 'Citrus fruits'];
      break;
    case 'veg':
      proteinSources = ['Legumes and lentils', 'Dairy (milk, yogurt, cheese)', 'Nuts and seeds', 'Eggs'];
      ironSources = ['Legumes, tofu, fortified cereals (combine with vitamin C-rich foods)', 'Leafy greens', 'Dried fruits'];
      calciumSources = ['Dairy products', 'Fortified plant-based milks', 'Leafy greens (kale, bok choy)', 'Tofu set with calcium'];
      folicAcidSources = ['Leafy greens', 'Legumes', 'Fortified grains', 'Citrus fruits', 'Avocado'];
      break;
    case 'jain':
      // Jain diet is vegetarian but excludes root vegetables and some other items based on religious principles
      proteinSources = ['Legumes and lentils (excluding root-based ones)', 'Dairy (milk, yogurt, cheese)', 'Nuts and seeds'];
      ironSources = ['Legumes (beans, lentils), tofu, fortified cereals (with vitamin C)', 'Leafy greens (spinach, lettuce - check for root avoidance)', 'Dried fruits (like raisins, dates)'];
      calciumSources = ['Dairy products', 'Fortified plant-based milks', 'Leafy greens (like kale, mustard greens - check for root)', 'Sesame seeds'];
      folicAcidSources = ['Leafy greens (spinach, lettuce - check)', 'Legumes', 'Fortified grains', 'Citrus fruits'];
      break;
    default:
      // Fallback to non-veg sources
      proteinSources = ['Chicken, fish, eggs, lean meat', 'Legumes and lentils', 'Dairy or alternatives'];
      ironSources = ['Red meat, poultry, fish', 'Legumes, tofu, fortified cereals (with vitamin C for absorption)'];
      calciumSources = ['Dairy products (milk, yogurt, cheese)', 'Fortified plant-based milks', 'Leafy greens'];
      folicAcidSources = ['Leafy greens (spinach, kale)', 'Legumes', 'Fortified grains', 'Citrus fruits'];
  }

  // Common pregnancy tips and foods to avoid
  const tips = [
    'Stay hydrated - aim for 8-12 glasses of water per day.',
    'Include a variety of colorful fruits and vegetables for vitamins and minerals.',
    'Choose whole grains over refined grains for more fiber and nutrients.',
    'Include healthy fats like avocado, nuts, seeds, and olive oil.',
  ];

  const foodsToLimit = [
    'High-mercury fish (shark, swordfish, king mackerel, tilefish)',
    'Unpasteurized dairy and juices',
    'Raw or undercooked meat, poultry, and seafood',
    'Excessive caffeine (limit to 200mg per day)',
    'Alcohol',
  ];

  // Let's also suggest a sample daily meal plan based on the recommendations
  // This is highly simplified and would be much more detailed in a real app
  const sampleMealPlan = {
    breakfast: 'Greek yogurt with berries and nuts, or scrambled eggs with whole grain toast and avocado',
    lunch: 'Lentil soup with a side salad and whole grain roll, or grilled chicken salad with mixed greens and vegetables',
    dinner: 'Baked salmon with quinoa and steamed broccoli, or chickpea curry with brown rice and vegetables',
    snacks: [
      'Apple slices with peanut butter',
      'Carrot sticks with hummus',
      'Handful of almonds or walnuts',
      'Orange or banana',
      'Cheese stick or cottage cheese',
    ],
  };

  return {
    week: clampedWeek,
    dietaryType,
    calories: Math.round(calories),
    protein: Math.round(protein),
    calcium,
    iron,
    folicAcid,
    proteinSources,
    ironSources,
    calciumSources,
    folicAcidSources,
    tips,
    foodsToLimit,
    sampleMealPlan,
  };
};

// Function to calculate nutritional intake from medical logs and journal entries (simplified)
// In a real app, we would have a food log or more detailed nutritional tracking.
// For now, we'll just return placeholder values that would be replaced by actual logged data.
export const getNutritionalIntake = () => {
  // This would normally come from a food logging feature
  // For demonstration, we'll return some average values
  return {
    calories: 2000, // placeholder
    protein: 60, // placeholder
    calcium: 800, // placeholder
    iron: 15, // placeholder
    folicAcid: 400, // placeholder
  };
};
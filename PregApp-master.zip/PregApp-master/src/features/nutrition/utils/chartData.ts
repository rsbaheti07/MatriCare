// Utility functions to format data for Recharts
import { getNutritionRecommendations, getNutritionalIntake } from '@/features/nutrition/utils/nutritionCalculations';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { supabase } from '@/lib/supabaseClient';
import { calculateWeeksPregnant } from '@/lib/utils/dateCalculations';

// Type for our nutritional data points
interface NutritionalDataPoint {
  name: string;
  value: number;
  // For time series data
  date?: string;
  week?: number;
}

// Format data for a bar chart showing nutrient intake vs recommendations
export const prepareNutrientComparisonData = (
  week: number,
  dietaryType: 'veg' | 'non-veg' | 'jain'
) => {
  const recommendations = getNutritionRecommendations(week, dietaryType);
  const intake = getNutritionalIntake(); // This would come from actual food/medical logs in a real implementation

  return [
    { name: 'Calories', intake: intake.calories, recommended: recommendations.calories, unit: 'kcal' },
    { name: 'Protein', intake: intake.protein, recommended: recommendations.protein, unit: 'g' },
    { name: 'Calcium', intake: intake.calcium, recommended: recommendations.calcium, unit: 'mg' },
    { name: 'Iron', intake: intake.iron, recommended: recommendations.iron, unit: 'mg' },
    { name: 'Folic Acid', intake: intake.folicAcid, recommended: recommendations.folicAcid, unit: 'mcg' },
  ];
};

// Format data for a line chart showing weight progression over time
// This would fetch from vitals_logs in a real implementation
export const prepareWeightProgressionData = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('vitals_logs')
      .select('weight_kg, logged_at')
      .eq('user_id', userId)
      .not('weight_kg', 'is', null)
      .order('logged_at', { ascending: true });

    if (error) throw error;

    // Format data for Recharts line chart
    return data.map((entry) => ({
      date: entry.logged_at,
      weight: entry.weight_kg ?? 0,
    }));
  } catch (error) {
    console.error('Error fetching weight progression data:', error);
    return []; // Return empty array on error
  };
};

// Format data for a pie chart showing macronutrient breakdown
export const prepareMacronutrientData = (
  week: number,
  dietaryType: 'veg' | 'non-veg' | 'jain'
) => {
  const recommendations = getNutritionRecommendations(week, dietaryType);

  // Simplified macronutrient split (in reality, this would be more sophisticated)
  // Assuming: 50% carbs, 20% protein, 30% fat of total calories
  const totalCalories = recommendations.calories;
  const carbsCal = totalCalories * 0.5;
  const proteinCal = totalCalories * 0.2;
  const fatCal = totalCalories * 0.3;

  // Convert to grams (carbs & protein: 4 cal/g, fat: 9 cal/g)
  const carbsG = carbsCal / 4;
  const proteinG = proteinCal / 4;
  const fatG = fatCal / 9;

  return [
    { name: 'Carbohydrates', value: carbsG },
    { name: 'Protein', value: proteinG },
    { name: 'Fat', value: fatG },
  ];
};

// Get current week and dietary type from user data
export const getUserNutritionContext = async () => {
  const { user } = useAuthStore.getState();
  const { formData } = useOnboardingStore.getState();

  if (!user || !formData.dueDate) {
    return { week: null, dietaryType: null };
  }

  const weeksPregnant = calculateWeeksPregnant(new Date().toISOString(), formData.dueDate);
  const dietaryType = formData.dietaryPreference ?? 'non-veg';

  return { week: weeksPregnant, dietaryType };
};
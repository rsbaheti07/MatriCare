'use client';

import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Calendar } from 'lucide-react';
import { useEffect } from 'react';

export const OnboardingFlow = () => {
  const { step, formData, setStep, setFormData, isComplete, setComplete } = useOnboardingStore();


  const handleDueDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ dueDate: e.target.value });
  };

  const handleGravidaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ gravida: parseInt(e.target.value) || null });
  };

  const handleParaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ para: parseInt(e.target.value) || null });
  };

  const handleDietaryPreferenceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFormData({ dietaryPreference: e.target.value as any });
  };

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      setComplete(true);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const isFormValid = () => {
    switch (step) {
      case 1:
        return !!formData.dueDate;
      case 2:
        return formData.gravida !== null && formData.gravida >= 1;
      case 3:
        return formData.para !== null && formData.para >= 0;
      case 4:
        return !!formData.dietaryPreference;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">
            {step === 1 ? 'Welcome to MatriCare' : step === 2 ? 'Pregnancy Details' : step === 3 ? 'More Details' : 'Almost Done!'}
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Let's get you set up for a healthy pregnancy journey
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <label className="flex flex-col space-y-1 text-sm font-medium text-muted-foreground">
                Expected Due Date
              </label>
              <Input
                type="date"
                value={formData.dueDate || ''}
                onChange={handleDueDateChange}
                required
                min={new Date().toISOString().split('T')[0]}
                max={new Date(Date.now() + 40 * 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]} // Max 40 weeks from now
              />
              <p className="text-sm text-muted-foreground">
                This helps us calculate your current week and provide personalized insights
              </p>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-4">
              <label className="flex flex-col space-y-1 text-sm font-medium text-muted-foreground">
                Gravida (Number of Pregnancies)
              </label>
              <Input
                type="number"
                min="1"
                value={formData.gravida !== null ? formData.gravida.toString() : ''}
                onChange={handleGravidaChange}
                required
                placeholder="Enter number of pregnancies"
              />
              <p className="text-sm text-muted-foreground">
                This is your current pregnancy count including this one
              </p>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-4">
              <label className="flex flex-col space-y-1 text-sm font-medium text-muted-foreground">
                Para (Number of Live Births)
              </label>
              <Input
                type="number"
                min="0"
                value={formData.para !== null ? formData.para.toString() : ''}
                onChange={handleParaChange}
                required
                placeholder="Enter number of live births"
              />
              <p className="text-sm text-muted-foreground">
                Number of pregnancies that have reached viable gestational age
              </p>
            </div>
          )}
          {step === 4 && (
            <div className="space-y-4">
              <label className="flex flex-col space-y-1 text-sm font-medium text-muted-foreground">
                Dietary Preference
              </label>
              <select
                value={formData.dietaryPreference || ''}
                onChange={handleDietaryPreferenceChange}
                required
                className="block w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="">Select your preference</option>
                <option value="veg">Vegetarian</option>
                <option value="non-veg">Non-Vegetarian</option>
                <option value="jain">Jain</option>
              </select>
              <p className="text-sm text-muted-foreground">
                This helps us provide culturally appropriate nutrition guidance
              </p>
            </div>
          )}
        </CardContent>
        <div className="flex items-center justify-between p-6 pt-0 border-t">
          {step > 1 && (
            <Button variant="outline" size="sm" onClick={handleBack}>
              Back
            </Button>
          )}
          <Button
            variant="default"
            size="sm"
            onClick={handleNext}
            disabled={!isFormValid()}
            className={step === 4 ? 'w-full' : 'auto'}
          >
            {step === 4 ? 'Complete Onboarding' : 'Next'}
          </Button>
        </div>
      </Card>
    </div>
  );
};
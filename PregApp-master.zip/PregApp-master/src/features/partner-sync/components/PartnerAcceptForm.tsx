'use client';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Mail } from 'lucide-react';

interface PartnerAcceptFormProps {
  inviteCode?: string;
}

export const PartnerAcceptForm = ({ inviteCode }: PartnerAcceptFormProps) => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm({
    defaultValues: {
      inviteCode: inviteCode || '',
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      if (!user) throw new Error('User not authenticated');

      // Find the invite by code
      const { data: invite, error: fetchError } = await supabase
        .from('partner_invites')
        .select('*')
        .eq('invite_code', data.inviteCode.toUpperCase())
        .single();

      if (fetchError) throw fetchError;
      if (!invite) throw new Error('Invalid invite code');
      if (invite.status !== 'pending') throw new Error('This invite has already been used or expired');
      if (new Date(invite.expires_at) < new Date()) throw new Error('This invite has expired');

      // Accept the invite by updating the invite record and creating a partner link
      const { data: result, error } = await supabase
        .from('partner_invites')
        .update({
          status: 'accepted',
          partner_id: user.id,
          accepted_at: new Date().toISOString(),
        })
        .eq('id', invite.id)
        .select()
        .single();

      if (error) throw error;

      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['partnerInvites'] });
      toast({
        title: 'Invitation accepted!',
        description: `You are now connected as a partner to ${data.partner_name}.`,
      });
      // Redirect to dashboard or partner view
      router.push('/dashboard');
    },
    onError: (error: any) => {
      toast({
        title: 'Error accepting invitation',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    mutation.mutate(data);
  });

  // If an inviteCode was provided via prop, we can automatically submit the form
  // But we'll leave it to the user to submit for now. We can add an auto-submit feature if needed.
  // useEffect(() => {
  //   if (inviteCode) {
  //     handleSubmit({ inviteCode });
  //   }
  // }, [inviteCode, handleSubmit]);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="invite-code">Invite Code</Label>
        <Input
          id="invite-code"
          type="text"
          placeholder="Enter the invite code you received"
          {...form.register('inviteCode', {
            required: 'Please enter an invite code',
            pattern: {
              value: /^[A-Z0-9]+$/,
              message: 'Please enter a valid invite code',
            },
            onChange: (e) => {
              form.setValue('inviteCode', e.target.value.toUpperCase());
            },
          })}
        />
        {form.formState.errors.inviteCode && (
          <p className="text-sm text-destructive">{form.formState.errors.inviteCode.message}</p>
        )}
      </div>

      <Button
        type="submit"
        disabled={mutation.isPending}
        className="w-full flex items-center justify-center space-x-2"
      >
        {mutation.isPending ? (
          <>
            <span className="animate-spin h-3 w-3 me-1"></span>
            Accepting...
          </>
        ) : (
          <>
            <Mail className="h-3 w-3 me-1" />
            Accept Invitation
          </>
        )}
      </Button>
    </form>
  );
};
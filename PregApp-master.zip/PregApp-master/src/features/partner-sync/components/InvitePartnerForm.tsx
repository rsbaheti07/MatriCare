'use client';

import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Mail } from 'lucide-react';

export const InvitePartnerForm = () => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm({
    defaultValues: {
      partnerEmail: '',
      partnerName: '',
    },
  });

  const mutation = useMutation<any, Error, any>({
    mutationFn: async (inputData: any): Promise<any> => {
      if (!user) throw new Error('User not authenticated');

      // Generate a unique invite code (in a real app, this would be done server-side)
      const inviteCode = Math.random().toString(36).substring(2, 10).toUpperCase();

      // In a real app, we'd send this to a backend function or use Supabase edge functions
      // For now, we'll simulate by storing in a partner_invites table
      const { data: inserted, error } = await supabase
        .from('partner_invites')
        .insert({
          inviter_id: user.id,
          partner_email: inputData.partnerEmail,
          partner_name: inputData.partnerName,
          invite_code: inviteCode,
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days expiry
          status: 'pending',
        })
        .single();

      if (error) throw error;
      if (!inserted) throw new Error('No inserted data returned');
      return inserted;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['partnerInvites'] });
      toast({
        title: 'Invitation sent!',
        description: `An invitation has been sent to ${data.partner_email}. They can use code: ${data.invite_code}`,
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error sending invitation',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    mutation.mutate(data);
  });

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="partner-email">Partner's Email</Label>
        <Input
          id="partner-email"
          type="email"
          placeholder="Enter your partner's email address"
          {...form.register('partnerEmail', {
            required: 'Please enter an email address',
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
              message: 'Please enter a valid email address',
            },
          })}
        />
        {form.formState.errors.partnerEmail && (
          <p className="text-sm text-destructive">{form.formState.errors.partnerEmail.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="partner-name">Partner's Name (Optional)</Label>
        <Input
          id="partner-name"
          type="text"
          placeholder="Enter your partner's name"
          {...form.register('partnerName')}
        />
      </div>

      <Button
        type="submit"
        disabled={mutation.isPending}
        className="w-full flex items-center justify-center space-x-2"
      >
        {mutation.isPending ? (
          <>
            <span className="animate-spin h-3 w-3 me-1"></span>
            Sending...
          </>
        ) : (
          <>
            <Mail className="h-3 w-3 me-1" />
            Send Invitation
          </>
        )}
      </Button>
    </form>
  );
};
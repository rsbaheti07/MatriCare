import { ChecklistItem } from './ChecklistItem';
import { CustomItemAdder } from './CustomItemAdder';
import { useChecklistItems } from '@/features/hospital-checklist/hooks/useChecklistItems';
import { cn } from '@/lib/utils';

interface ChecklistCategoryProps {
  category: string;
}

export const ChecklistCategory = ({ category }: ChecklistCategoryProps) => {
  const { items, isLoading, error, toggleItem, addCustomItem, removeCustomItem, updateCustomItemDescription } = useChecklistItems(category);

  if (isLoading) {
    return (
      <div className="py-4">
        <div className="text-center">
          <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4">
        <p className="text-sm text-destructive">Error loading checklist items</p>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <h2 className="text-lg font-semibold mb-2">{category}</h2>
      <div className="space-y-2">
        {items.map((item) => (
          <ChecklistItem
            key={item.id}
            id={item.id}
            description={item.custom_description || item.description}
            isPacked={item.is_packed}
            isCustom={item.isCustom}
            onToggle={() => toggleItem(item.id)}
            onRemove={item.isCustom ? () => removeCustomItem(item.id) : undefined}
            onEditDescription={item.isCustom ? (newDesc: string) => updateCustomItemDescription(item.id, newDesc) : undefined}
          />
        ))}
        {/* Add custom item button */}
        <CustomItemAdder category={category} onAddItem={addCustomItem} />
      </div>
    </div>
  );
};
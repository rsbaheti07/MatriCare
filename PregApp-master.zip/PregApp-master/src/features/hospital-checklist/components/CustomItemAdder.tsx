import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface CustomItemAdderProps {
  category: string;
  onAddItem: (description: string) => Promise<void>;
}

export const CustomItemAdder = ({ category, onAddItem }: CustomItemAdderProps) => {
  const { toast } = useToast();
  const [customDescription, setCustomDescription] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (customDescription.trim()) {
      try {
        await onAddItem(customDescription.trim());
        setCustomDescription('');
        toast({
          title: 'Custom item added',
          description: 'Your custom item has been added to the checklist.',
        });
      } catch (error: any) {
        toast({
          title: 'Error adding custom item',
          description: error.message,
          variant: 'destructive',
        });
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-4 flex space-x-2">
      <Input
        placeholder="Add your own item..."
        value={customDescription}
        onChange={(e) => setCustomDescription(e.target.value)}
        className="flex-1"
      />
      <Button type="submit" disabled={!!customDescription.trim() === false}>
        {customDescription.trim() === '' ? 'Add Item' : 'Adding...'}
      </Button>
    </form>
  );
};
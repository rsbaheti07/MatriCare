import { CheckCircle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ChecklistItemProps {
  id: string;
  description: string;
  isPacked: boolean;
  isCustom: boolean;
  onToggle: (id: string) => void;
  onRemove?: (id: string) => void; // Only for custom items
  onEditDescription?: (id: string, newDescription: string) => void; // For custom items
}

export const ChecklistItem = ({
  id,
  description,
  isPacked,
  isCustom,
  onToggle,
  onRemove,
  onEditDescription
}: ChecklistItemProps) => {
  const handleToggle = () => {
    onToggle(id);
  };

  const handleRemove = () => {
    if (onRemove) {
      onRemove(id);
    }
  };

  // We'll make the description editable on double-click for custom items
  // For simplicity in this implementation, we'll just show the description and allow editing via a separate button
  // Alternatively, we can make it an inline editor on double-click, but let's keep it simple with an edit button for custom items.

  return (
    <label className={cn("flex items-center space-x-3", isPacked && "opacity-75")}>
      <input
        type="checkbox"
        checked={isPacked}
        onChange={handleToggle}
        className="h-4 w-4 text-primary rounded border-gray-300"
      />
      <div className="flex-1 space-y-1">
        <span className={cn(
          "block text-sm font-medium text-foreground",
          isPacked && "line-through text-muted-foreground"
        )}>
          {description}
        </span>
        {isCustom && (
          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                // In a real implementation, we would open an editor or prompt for new description
                // For now, we'll just call the onEditDescription callback with a placeholder
                // We'll leave this as a stub for the user to implement if needed
                // onEditDescription && onEditDescription(id, window.prompt('Edit item:', description) || description);
              }}
            >
              <X className="h-3 w-3" /> Edit
            </Button>
          </div>
        )}
      </div>
      {isCustom && onRemove ? (
        <Button
          variant="ghost"
          size="icon"
          onClick={handleRemove}
          aria-label="Remove item"
        >
          <X className="h-3 w-3" />
        </Button>
      ) : null}
    </label>
  );
};
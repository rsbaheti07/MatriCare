import { useChecklistItems } from '@/features/hospital-checklist/hooks/useChecklistItems';
import { getChecklistCategories } from '@/features/hospital-checklist/utils/checklistItems';
import { cn } from '@/lib/utils';

interface ProgressBarProps {
  className?: string;
}

export const ProgressBar = ({ className = '' }: ProgressBarProps) => {
  const categories = getChecklistCategories();
  const categoryData = categories.map((category) => {
    const { items, isLoading } = useChecklistItems(category);
    return { category, items, isLoading };
  });

  // Calculate overall progress
  const totalItems = categoryData.reduce((sum, catData) => sum + (catData.items?.length || 0), 0);
  const packedItems = categoryData.reduce((sum, catData) => {
    if (catData.isLoading) return sum;
    return sum + catData.items.filter(item => item.is_packed).length;
  }, 0);

  const progressPercentage = totalItems > 0 ? (packedItems / totalItems) * 100 : 0;

  return (
    <div className={cn("w-full bg-muted/50 rounded-full h-2.5 mb-4", className)}>
      <div
        className="flex-1 h-2.5 rounded-full bg-primary"
        style={{ width: `${progressPercentage}%` }}
      ></div>
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{packedItems}/{totalItems} items packed</span>
        <span>{Math.round(progressPercentage)}% complete</span>
      </div>
    </div>
  );
};
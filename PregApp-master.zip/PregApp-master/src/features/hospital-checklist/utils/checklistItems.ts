// Predefined hospital bag checklist items organized by category
export const HOSPITAL_CHECKLIST_ITEMS = [
  // Mom's Items
  {
    id: 'mom-1',
    category: 'Mom',
    description: 'Insurance card and hospital paperwork',
    isCustom: false,
    sortOrder: 1
  },
  {
    id: 'mom-2',
    category: 'Mom',
    description: 'Birth plan (if you have one)',
    isCustom: false,
    sortOrder: 2
  },
  {
    id: 'mom-3',
    category: 'Mom',
    description: 'Toiletries (toothbrush, toothpaste, shampoo, conditioner, soap)',
    isCustom: false,
    sortOrder: 3
  },
  {
    id: 'mom-4',
    category: 'Mom',
    description: 'Hairbrush and hair ties',
    isCustom: false,
    sortOrder: 4
  },
  {
    id: 'mom-5',
    category: 'Mom',
    description: 'Nursing bras (2-3)',
    isCustom: false,
    sortOrder: 5
  },
  {
    id: 'mom-6',
    category: 'Mom',
    description: 'Nursing pads',
    isCustom: false,
    sortOrder: 6
  },
  {
    id: 'mom-7',
    category: 'Mom',
    description: 'Going-home outfit (comfortable clothes)',
    isCustom: false,
    sortOrder: 7
  },
  {
    id: 'mom-8',
    category: 'Mom',
    description: 'Slippers or comfortable shoes',
    isCustom: false,
    sortOrder: 8
  },
  {
    id: 'mom-9',
    category: 'Mom',
    description: 'Phone charger and portable power bank',
    isCustom: false,
    sortOrder: 9
  },
  {
    id: 'mom-10',
    category: 'Mom',
    description: 'Lip balm (hospital air can be drying)',
    isCustom: false,
    sortOrder: 10
  },
  {
    id: 'mom-11',
    category: 'Mom',
    description: 'Snacks for labor (if allowed by hospital)',
    isCustom: false,
    sortOrder: 11
  },
  {
    id: 'mom-12',
    category: 'Mom',
    description: 'Massage oil or lotion (for partner to use during labor)',
    isCustom: false,
    sortOrder: 12
  },
  {
    id: 'mom-13',
    category: 'Mom',
    description: 'Playlist or meditation app for labor',
    isCustom: false,
    sortOrder: 13
  },

  // Baby's Items
  {
    id: 'baby-1',
    category: 'Baby',
    description: 'Going-home outfit (onesie, socks, hat)',
    isCustom: false,
    sortOrder: 1
  },
  {
    id: 'baby-2',
    category: 'Baby',
    description: 'Blanket or swaddle',
    isCustom: false,
    sortOrder: 2
  },
  {
    id: 'baby-3',
    category: 'Baby',
    description: 'Diapers (newborn size, hospital usually provides but good to have)',
    isCustom: false,
    sortOrder: 3
  },
  {
    id: 'baby-4',
    category: 'Baby',
    description: 'Wipes',
    isCustom: false,
    sortOrder: 4
  },
  {
    id: 'baby-5',
    category: 'Baby',
    description: 'Baby bathtowel (hooded preferred)',
    isCustom: false,
    sortOrder: 5
  },
  {
    id: 'baby-6',
    category: 'Baby',
    description: 'Infant car seat (already installed in car)',
    isCustom: false,
    sortOrder: 6
  },

  // Partner/Support Person Items
  {
    id: 'partner-1',
    category: 'Partner',
    description: 'Change of clothes',
    isCustom: false,
    sortOrder: 1
  },
  {
    id: 'partner-2',
    category: 'Partner',
    description: 'Toiletries',
    isCustom: false,
    sortOrder: 2
  },
  {
    id: 'partner-3',
    category: 'Partner',
    description: 'Snacks and drinks',
    isCustom: false,
    sortOrder: 3
  },
  {
    id: 'partner-4',
    category: 'Partner',
    description: 'Phone charger',
    isCustom: false,
    sortOrder: 4
  },
  {
    id: 'partner-5',
    category: 'Partner',
    description: 'Camera or video recorder (if phone not sufficient)',
    isCustom: false,
    sortOrder: 5
  },
  {
    id: 'partner-6',
    category: 'Partner',
    description: 'Reading material or games for downtime',
    isCustom: false,
    sortOrder: 6
  },

  // Documents and Essentials
  {
    id: 'docs-1',
    category: 'Documents',
    description: 'Photo ID',
    isCustom: false,
    sortOrder: 1
  },
  {
    id: 'docs-2',
    category: 'Documents',
    description: 'Insurance information',
    isCustom: false,
    sortOrder: 2
  },
  {
    id: 'docs-3',
    category: 'Documents',
    description: 'Hospital registration forms (if pre-registration not done)',
    isCustom: false,
    sortOrder: 3
  },
  {
    id: 'docs-4',
    category: 'Documents',
    description: 'List of emergency contacts',
    isCustom: false,
    sortOrder: 4
  },
  {
    id: 'docs-5',
    category: 'Documents',
    description: 'Birth plan copies',
    isCustom: false,
    sortOrder: 5
  },

  // Extras and Comfort Items
  {
    id: 'extras-1',
    category: 'Extras',
    description: 'Pillow from home (hospital pillows may not be comfortable)',
    isCustom: false,
    sortOrder: 1
  },
  {
    id: 'extras-2',
    category: 'Extras',
    description: 'Robe or nightgown',
    isCustom: false,
    sortOrder: 2
  },
  {
    id: 'extras-3',
    category: 'Extras',
    description: 'Books, magazine, or tablet for entertainment',
    isCustom: false,
    sortOrder: 3
  },
  {
    id: 'extras-4',
    category: 'Extras',
    description: 'Eye mask and earplugs (for better sleep)',
    isCustom: false,
    sortOrder: 4
  },
  {
    id: 'extras-5',
    category: 'Extras',
    description: 'Hand sanitizer',
    isCustom: false,
    sortOrder: 5
  }
];

// Function to get items by category
export const getChecklistItemsByCategory = (category: string) => {
  return HOSPITAL_CHECKLIST_ITEMS
    .filter(item => item.category === category && !item.isCustom)
    .sort((a, b) => a.sortOrder - b.sortOrder);
};

// Function to get all categories
export const getChecklistCategories = () => {
  return [...new Set(HOSPITAL_CHECKLIST_ITEMS.map(item => item.category))];
};

// Function to get default items for a user (non-custom items)
export const getDefaultChecklistItems = () => {
  return HOSPITAL_CHECKLIST_ITEMS.filter(item => !item.isCustom);
};
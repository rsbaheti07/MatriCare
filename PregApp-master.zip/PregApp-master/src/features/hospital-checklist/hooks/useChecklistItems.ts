import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { HOSPITAL_CHECKLIST_ITEMS, getChecklistItemsByCategory } from '@/features/hospital-checklist/utils/checklistItems';

interface ChecklistItemState extends Omit<typeof HOSPITAL_CHECKLIST_ITEMS[0], 'sortOrder'> {
  is_packed: boolean;
  custom_description?: string;
}

/**
 * Hook to get checklist items for a specific category, merging predefined items with user's state from Supabase
 * @param category The category to filter items by (e.g., 'Mom', 'Baby', etc.)
 */
export const useChecklistItems = (category: string) => {
  const { user } = useAuthStore();
  const [items, setItems] = useState<ChecklistItemState[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserChecklist = async () => {
      if (!user) {
        // If no user, return predefined items with default unpacked state
        const predefined = getChecklistItemsByCategory(category);
        setItems(
          predefined.map((item) => ({
            ...item,
            is_packed: false,
            custom_description: undefined,
          }))
        );
        setIsLoading(false);
        return;
      }

      try {
        // Fetch user's checklist state for this category
        const { data: userItems, error: userError } = await supabase
          .from('user_hospital_checklist')
          .select('*')
          .eq('user_id', user.id)
          .eq('category', category);

        if (userError) throw userError;

        // Create a map of user item states by item_id for quick lookup
        const userItemMap = new Map<string, ChecklistItemState>();
        userItems?.forEach((item) => {
          userItemMap.set(item.item_id, {
            id: item.id,
            description: item.custom_description || '',
            isCustom: item.is_custom,
            is_packed: item.is_packed,
            custom_description: item.custom_description,
            category: item.category,
          });
        });

        // Get predefined items for the category
        const predefinedItems = getChecklistItemsByCategory(category);

        // Merge predefined items with user state
        const mergedItems: ChecklistItemState[] = predefinedItems.map((predefined) => {
          const userState = userItemMap.get(predefined.id);
          if (userState) {
            // User has a state for this predefined item (could be custom or not)
            return {
              id: userState.id,
              description: userState.description,
              isCustom: userState.isCustom,
              is_packed: userState.is_packed,
              custom_description: userState.custom_description,
              category: category,
            };
          } else {
            // No user state yet, default to unpacked
            return {
              id: predefined.id,
              description: predefined.description,
              isCustom: predefined.isCustom,
              is_packed: false,
              custom_description: undefined,
              category: category,
            };
          }
        });

        setItems(mergedItems);
      } catch (err: any) {
        setError(err.message);
        // Fallback to predefined items on error
        const predefined = getChecklistItemsByCategory(category);
        setItems(
          predefined.map((item) => ({
            ...item,
            is_packed: false,
            custom_description: undefined,
          }))
        );
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserChecklist();
  }, [user, category]);

  // Function to toggle an item's packed state
  const toggleItem = async (itemId: string) => {
    if (!user) return;

    // Find the item in our current state to get its current state
    const item = items.find((i) => i.id === itemId);
    if (!item) return;

    try {
      const { error } = await supabase
        .from('user_hospital_checklist')
        .upsert(
          {
            user_id: user.id,
            item_id: itemId,
            is_custom: item.isCustom,
            is_packed: !item.is_packed, // Toggle the state
            custom_description: item.custom_description,
            category: category,
          },
          { onConflict: 'user_id,item_id' }
        );

      if (error) throw error;

      // Update local state optimistically
      setItems(
        items.map((i) =>
          i.id === itemId
            ? { ...i, is_packed: !i.is_packed }
            : i
        )
      );
    } catch (err: any) {
      setError(err.message);
      // In a real app, we might want to revert the optimistic update
    }
  };

  // Function to add a custom item
  const addCustomItem = async (description: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_hospital_checklist')
        .insert({
          user_id: user.id,
          item_id: `${Math.random().toString(36).substring(2, 10)}`, // Simple random ID
          is_custom: true,
          is_packed: false,
          custom_description: description,
          category: category,
        });

      if (error) throw error;

      // Refetch to include the new item
      // We'll trigger a refetch by invalidating and refetching, but for simplicity we'll just call the effect again
      // In practice, we would use a query client or refetch function
      // For now, we'll just add it to the local state optimistically
      setItems([
        ...items,
        {
          id: `${Math.random().toString(36).substring(2, 10)}`,
          description: description,
          isCustom: true,
          is_packed: false,
          custom_description: description,
          category: category,
        },
      ]);
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Function to remove a custom item
  const removeCustomItem = async (itemId: string) => {
    if (!user) return;

    // Find the item to confirm it's custom
    const item = items.find((i) => i.id === itemId);
    if (!item || !item.isCustom) return;

    try {
      const { error } = await supabase
        .from('user_hospital_checklist')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      // Remove from local state
      setItems(items.filter((i) => i.id !== itemId));
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Function to update a custom item's description
  const updateCustomItemDescription = async (itemId: string, newDescription: string) => {
    if (!user) return;

    // Find the item to confirm it's custom
    const item = items.find((i) => i.id === itemId);
    if (!item || !item.isCustom) return;

    try {
      const { error } = await supabase
        .from('user_hospital_checklist')
        .update({
          custom_description: newDescription,
          updated_at: new Date().toISOString(),
        })
        .eq('id', itemId);

      if (error) throw error;

      // Update local state
      setItems(
        items.map((i) =>
          i.id === itemId ? { ...i, custom_description: newDescription } : i
        )
      );
    } catch (err: any) {
      setError(err.message);
    }
  };

  return {
    items,
    isLoading,
    error,
    toggleItem,
    addCustomItem,
    removeCustomItem,
    updateCustomItemDescription,
  };
};
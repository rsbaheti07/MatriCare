'use client';
import PostCard from './PostCard';
import { cn } from '@/lib/utils';

interface Post {
  id: string;
  user_id: string;
  content: string;
  created_at: string;
  user_full_name?: string;
  user_avatar_url?: string;
  tags?: string[];
}

interface PostListProps {
  posts: Post[];
  className?: string;
}

export const PostList = ({ posts, className = '' }: PostListProps) => {
  return (
    <div className={cn('space-y-4', className)}>
      {posts.length > 0 ? (
        posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No posts yet. Be the first to share!</p>
        </div>
      )}
    </div>
  );
};
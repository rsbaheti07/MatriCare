'use client';

import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { TagSelect } from './TagSelect';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export const NewPostForm = () => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isPublic, setIsPublic] = useState(true); // Default to public (visible to all)

  const form = useForm({
    defaultValues: {
      content: '',
      tags: [] as string[], // Initialize tags as empty array
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      if (!user) throw new Error('User not authenticated');
      const { data: result, error } = await supabase
        .from('community_posts')
        .insert({
          user_id: user.id,
          content: data.content,
          tags: data.tags, // Add tags to the insert
          is_public: isPublic, // We'll add this column to the table
        });

      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast({
        title: 'Post shared successfully',
        description: 'Your post has been shared with the community.',
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error sharing post',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = form.handleSubmit((data) => {
    mutation.mutate({ ...data, tags: data.tags || [] });
  });

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="post-content">What's on your mind?</Label>
          <Input
            id="post-content"
            type="text"
            placeholder="Share your thoughts, questions, or experiences..."
            {...form.register('content', {
              required: 'Please share something',
              maxLength: 500,
            })}
          />
          {form.formState.errors.content && (
            <p className="text-sm text-destructive">{form.formState.errors.content.message}</p>
          )}
        </div>

        <div className="space-y-4">
          <Label htmlFor="post-tags">Add Tags (Optional)</Label>
          <TagSelect
            value={form.watch('tags') || []}
            onChange={(tags) => form.setValue('tags', tags)}
          />
        </div>

        <div className="space-y-4">
          <Label htmlFor="share-with-community">Share with Community</Label>
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="share-with-community"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
            />
            <span className="text-sm text-muted-foreground">
              Share publicly (visible to all users)
            </span>
          </div>
        </div>
      </div>

      <Button
        type="submit"
        disabled={mutation.isPending}
        className="w-full"
      >
        {mutation.isPending ? 'Sharing...' : 'Share Post'}
      </Button>
    </form>
  );
};
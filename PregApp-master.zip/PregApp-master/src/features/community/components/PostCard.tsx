'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { User } from 'lucide-react';
import { TagBadge } from './TagBadge';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/hooks/use-toast';

interface Post {
  id: string;
  user_id: string;
  content: string;
  created_at: string;
  user_full_name?: string;
  user_avatar_url?: string;
  tags?: string[];
}

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const { user } = useAuthStore();
  const { toast } = useToast();

  const handleLike = async () => {
    if (!user) {
      toast({
        title: 'Please log in to like posts',
        description: 'You need to be logged in to like posts.',
        variant: 'destructive',
      });
      return;
    }

    // Toggle like: check if already liked, then unlike or like
    // For simplicity, we'll just add a like (assuming we have a likes table)
    // Since we don't have a likes table set up, we'll just show a toast for now.
    toast({
      title: 'Liked!',
      description: 'You liked this post.',
    });
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex items-center space-x-3">
        {post.user_avatar_url ? (
          <Image
            src={post.user_avatar_url}
            alt="User avatar"
            width={32}
            height={32}
            className="rounded-full"
          />
        ) : (
          <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
            <User className="h-4 w-4" />
          </div>
        )}
        <div className="space-y-1">
          <CardTitle className="text-sm font-medium">
            {post.user_full_name || 'Anonymous User'}
          </CardTitle>
          <CardDescription className="text-xs text-muted-foreground">
            {new Date(post.created_at).toLocaleString('en-IN', {
              dateStyle: 'short',
              timeStyle: 'short',
            })}
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent className="py-4">
        <p className="text-muted-foreground">{post.content}</p>
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap space-x-2 mt-3">
            {post.tags.map((tag, index) => (
              <TagBadge key={index} tag={tag} />
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex items-center space-x-4 pt-4">
        <Button variant="outline" size="sm" onClick={handleLike}>
          <User className="h-3 w-3 me-1" />
          Like
        </Button>
        <Button variant="outline" size="sm" asChild>
          {/* In a real app, this would open a comment modal */}
          <span>Comment</span>
        </Button>
        <Button variant="outline" size="sm" asChild>
          {/* Share */}
          <span>Share</span>
        </Button>
      </CardFooter>
    </Card>
  );
}
import * as React from "react"
import { cn } from "@/lib/utils"

interface TagBadgeProps {
  tag: string
  className?: string
}

export const TagBadge = ({
  tag,
  className = ""
}: TagBadgeProps) => {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
        "bg-primary/10 text-primary",
        className
      )}
    >
      #{tag}
    </span>
  )
}
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TagBadge } from './TagBadge';
import { ChevronDown, X } from 'lucide-react';
import { cn } from '@/lib/utils';

// Predefined pregnancy-related tags (20-30 most important things)
const PREDEFINED_TAGS = [
  'Nutrition',
  'Exercise',
  'Morning Sickness',
  'Cravings',
  'Doctor Visits',
  'Ultrasound',
  'Blood Tests',
  'Maternity Clothing',
  'Baby Gear',
  'Nursery Setup',
  'Birth Planning',
  'Labor & Delivery',
  'C-Section',
  'Breastfeeding',
  'Postpartum Recovery',
  'Mental Health',
  'Gender Reveal',
  'Baby Shower',
  'Names',
  'First Trimester',
  'Second Trimester',
  'Third Trimester',
  'Twins/Multiples',
  'High Risk Pregnancy',
  'Travel',
  'Work',
  'Sleep',
  'Stretch Marks',
  'Fetal Movement',
  'Heartburn',
  'Back Pain'
];

interface TagSelectProps {
  value: string[];
  onChange: (tags: string[]) => void;
  className?: string;
}

export const TagSelect = ({
  value,
  onChange,
  className = ''
}: TagSelectProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');

  // Filter tags based on search
  const filteredTags = PREDEFINED_TAGS.filter(tag =>
    tag.toLowerCase().includes(search.toLowerCase())
  );

  const handleTagClick = (tag: string) => {
    if (value.includes(tag)) {
      // Remove tag
      onChange(value.filter(t => t !== tag));
    } else {
      // Add tag
      onChange([...value, tag]);
    }
  };

  return (
    <div className={className}>
      <div className="flex items-center space-x-2">
        <Input
          placeholder="Search tags..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-[200px]"
        />
        <Button
          variant="outline"
          size="icon"
          onClick={() => setIsOpen(!isOpen)}
          className="h-9 w-9"
        >
          {isOpen ? <X className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>

      {isOpen && (
        <div className="mt-2 w-[200px] border border-muted/50 rounded-lg bg-background z-10">
          <div className="max-h-[200px] overflow-y-auto">
            {filteredTags.map((tag) => (
              <button
                key={tag}
                onClick={() => handleTagClick(tag)}
                className={cn(
                  "flex w-full items-center space-x-2 px-3 py-2 text-left text-sm",
                  value.includes(tag) && "bg-primary/50 text-primary",
                  !value.includes(tag) && "hover:bg-muted/50"
                )}
              >
                <TagBadge tag={tag} className={value.includes(tag) ? "bg-primary/20 text-primary" : ""} />
                <span className="flex-1">{tag}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
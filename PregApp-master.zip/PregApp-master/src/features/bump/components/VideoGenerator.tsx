'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useToast } from '@/hooks/use-toast';

export const VideoGenerator = () => {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateVideo = async () => {
    if (!user) return;

    setIsGenerating(true);
    setError(null);

    try {
      // Fetch all bump photos for the user
      const { data: photos, error: photosError } = await supabase
        .from('bump_photos')
        .select('*')
        .eq('user_id', user.id)
        .order('captured_at', { ascending: true });

      if (photosError) throw photosError;

      if (!photos || photos.length === 0) {
        throw new Error('No photos available to create video');
      }

      // For now, we'll simulate video generation
      // In a real implementation, this would use Canvas API or a serverless function
      // to create a video from the photos

      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Create a mock video URL (in reality, this would be the actual generated video)
      const mockVideoUrl = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/bump-videos/${user.id}/timelapse-${Date.now()}.mp4`;

      // Save video metadata to bump_videos table
      const weeksCovered = {
        start_week: Math.min(...photos.map(p => p.week_number)),
        end_week: Math.max(...photos.map(p => p.week_number))
      };

      const { data: videoData, error: videoError } = await supabase
        .from('bump_videos')
        .insert({
          user_id: user.id,
          video_url: mockVideoUrl,
          photo_count: photos.length,
          weeks_covered: weeksCovered,
        });

      if (videoError) throw videoError;

      setVideoUrl(mockVideoUrl);
      toast({
        title: 'Video Generated!',
        description: 'Your bump timelapse video has been created.',
      });
    } catch (err: any) {
      setError(err.message);
      toast({
        title: 'Video Generation Error',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold mb-4">Generate Timelapse Video</h2>

      {isGenerating ? (
        <div className="flex items-center space-x-3">
          <div className="h-4 w-4 border border-primary/50 rounded-full border-t-primary/70 animate-spin" />
          <span>Generating video...</span>
        </div>
      ) : (
        <>
          {videoUrl && (
            <div className="border rounded-lg overflow-hidden">
              <video
                src={videoUrl}
                controls
                className="w-full h-48"
              />
            </div>
          )}

          <button
            onClick={generateVideo}
            disabled={isGenerating}
            className="btn btn-primary w-full"
          >
            {isGenerating ? 'Generating...' : 'Generate Video'}
          </button>

          {!isGenerating && !videoUrl && (
            <p className="text-sm text-muted-foreground">
              You need at least 2 photos to create a timelapse video.
            </p>
          )}
        </>
      )}

      {error && (
        <div className="p-4 bg-destructive/10 rounded-lg border border-destructive/20 text-destructive">
          Error: {error}
        </div>
      )}
    </div>
  );
};
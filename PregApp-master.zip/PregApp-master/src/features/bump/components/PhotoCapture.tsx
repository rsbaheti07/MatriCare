'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { Circle, Plus, X } from 'lucide-react';
import Image from 'next/image';

export const PhotoCapture = () => {
  const { user } = useAuthStore();
  const { formData } = useOnboardingStore();
  const { toast } = useToast();
  const router = useRouter();

  const [isStreamActive, setIsStreamActive] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [lastPhoto, setLastPhoto] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Calculate current week from due date
  const weeksPregnant = formData.dueDate
    ? Math.ceil(
        (new Date().getTime() - new Date(formData.dueDate).getTime()) /
          (1000 * 60 * 60 * 24 * 7)
      )
    : 0;

  useEffect(() => {
    return () => {
      // Clean up stream on unmount
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
      });
      streamRef.current = stream;
      videoRef.current!.srcObject = stream;
      setIsStreamActive(true);
    } catch (err) {
      console.error('Error accessing camera:', err);
      toast({
        title: 'Camera Error',
        description: 'Unable to access camera. Please grant permission and try again.',
        variant: 'destructive',
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsStreamActive(false);
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setIsCapturing(true);
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      setIsCapturing(false);
      return;
    }
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const photoDataUrl = canvas.toDataURL('image/jpeg', 0.9);

    // Upload to Supabase Storage
    try {
      const { user } = useAuthStore.getState();
      if (!user) throw new Error('User not authenticated');

      // Convert data URL to blob
      const blob = await (await fetch(photoDataUrl)).blob();
      const file = new Blob([blob], { type: 'image/jpeg' });
      const fileName = `bump-photos/${user.id}/${Date.now()}.jpg`;

      const { data, error } = await supabase.storage
        .from('bump-photos')
        .upload(fileName, file, {
          contentType: 'image/jpeg',
          upsert: false,
        });

      if (error) throw error;

      // Get public URL (assuming bucket is public) or signed URL
      // For simplicity, we'll assume the bucket is public. In production, use signed URLs.
      const { data: urlData } = await supabase.storage
        .from('bump-photos')
        .getPublicUrl(fileName);

      const publicUrl = urlData.publicUrl;

      // Save metadata to bump_photos table
      const { data: photoData, error: photoError } = await supabase
        .from('bump_photos')
        .insert({
          user_id: user.id,
          photo_url: publicUrl,
          week_number: weeksPregnant,
          captured_at: new Date().toISOString(),
          alignment_data: null, // Could be enhanced with actual alignment data later
        });

      if (photoError) throw photoError;

      setLastPhoto(publicUrl);
      toast({
        title: 'Photo Captured!',
        description: 'Your bump photo has been saved.',
      });

      // Update last capture time for reminder logic
      localStorage.setItem('lastBumpPhotoCapture', Date.now().toString());

    } catch (err: any) {
      console.error('Error uploading photo:', err);
      toast({
        title: 'Upload Error',
        description: err.message,
        variant: 'destructive',
      });
    } finally {
      setIsCapturing(false);
    }
  };

  if (!user) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">Please log in to use the bump photo feature.</p>
      </div>
    );
  }

  if (!formData.dueDate) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">
          Please set your due date in onboarding to use the bump photo feature.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        {!isStreamActive && (
          <Button
            onClick={startCamera}
            className="w-full"
          >
            Start Camera
          </Button>
        )}
        {isStreamActive && (
          <>
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-[300px] bg-muted rounded"
            />
            <canvas ref={canvasRef} style={{ display: 'none' }} />
            {/* Alignment overlays */}
            <div className="absolute inset-0 pointer-events-none">
              {/* Grid overlay */}
              <div className="absolute inset-0 grid grid-cols-4 grid-rows-3 gap-4">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="border border-dashed border-primary/20" />
                ))}
              </div>
              {/* Optional: face outline ellipse */}
              <div className="absolute inset-0 flex items-center justify-center">
                <svg className="w-12 h-12 stroke-primary stroke-2" fill="none">
                  <ellipse cx="0" cy="0" rx="60" ry="80" />
                </svg>
              </div>
            </div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center space-x-2">
              <Button
                variant="outline"
                onClick={capturePhoto}
                disabled={isCapturing}
                className="flex items-center space-x-2"
              >
                {isCapturing ? (
                  <>
                    <X className="h-4 w-4 animate-spin" />
                    Capturing...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4" />
                    Capture Photo
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                onClick={stopCamera}
                className="text-xs"
              >
                Stop
              </Button>
            </div>
          </>
        )}
      </div>

      {/* Last captured photo preview */}
      {lastPhoto && (
        <div className="relative">
          <Image
            src={lastPhoto}
            alt="Captured bump photo"
            className="rounded-lg w-full h-[300px] object-cover"
          />
          <div className="absolute bottom-2 left-2 bg-primary/90 text-primary-foreground text-xs px-2 py-1 rounded">
            Week {weeksPregnant}
          </div>
        </div>
      )}

      {/* Notice about weekly reminders */}
      <div className="p-4 bg-muted/50 rounded">
        <p className="text-sm text-muted-foreground">
          Tip: Take a photo every week at the same time of day for the best timelapse video.
          We'll remind you weekly to capture your bump progression.
        </p>
      </div>
    </div>
  );
};
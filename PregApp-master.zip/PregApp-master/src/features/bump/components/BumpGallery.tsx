import { useBumpPhotos } from '@/features/bump/hooks/useBumpPhotos';

export const BumpGallery = () => {
  const { photos, loading, error } = useBumpPhotos();

  if (loading) {
    return <div className="text-center py-8">Loading your bump photos...</div>;
  }

  if (error) {
    return <div className="text-center py-8 text-destructive">Error loading photos: {error}</div>;
  }

  if (!photos || photos.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No bump photos captured yet. Start capturing your weekly bump progression!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold mb-4">Your Bump Photos</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {photos.map((photo: any) => (
          <div key={photo.id} className="border rounded-lg overflow-hidden">
            <img
              src={photo.photo_url}
              alt={`Bump photo week ${photo.week_number}`}
              className="w-full h-48 object-cover"
            />
            <div className="p-3">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Week {photo.week_number}</span>
                <span>{new Date(photo.captured_at).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
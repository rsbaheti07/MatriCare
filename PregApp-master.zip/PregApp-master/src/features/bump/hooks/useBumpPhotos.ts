'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';

export const useBumpPhotos = () => {
  const { user } = useAuthStore();
  const [photos, setPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPhotos = async () => {
      if (!user) return;
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('bump_photos')
          .select('*')
          .eq('user_id', user.id)
          .order('captured_at', { ascending: true });

        if (error) throw error;
        setPhotos(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPhotos();
  }, [user]);

  return { photos, loading, error };
};
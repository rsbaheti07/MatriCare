'use client';
import { useState, useEffect } from 'react';

export const useBumpReminder = () => {
  const [showReminder, setShowReminder] = useState(false);

  useEffect(() => {
    const checkReminder = () => {
      const lastCapture = localStorage.getItem('lastBumpPhotoCapture');
      if (lastCapture) {
        const lastCaptureTime = parseInt(lastCapture, 10);
        const now = Date.now();
        const oneWeek = 7 * 24 * 60 * 60 * 1000;
        if (now - lastCaptureTime > oneWeek) {
          setShowReminder(true);
        } else {
          setShowReminder(false);
        }
      } else {
        // No capture yet, we don't show reminder for first photo
        setShowReminder(false);
      }
    };

    // Check on mount
    checkReminder();

    // Also check every hour
    const interval = setInterval(checkReminder, 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return showReminder;
};
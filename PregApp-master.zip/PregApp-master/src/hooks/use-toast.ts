import { toast } from 'sonner';

export const useToast = () => {
  return {
    toast: (options: { title: string; description?: string; variant?: 'default' | 'destructive' }) => {
      // sonner's toast function takes a description and then options
      // We'll map our options to sonner's expected parameters
      const { title, description, variant } = options;
      // sonner's toast: toast(description, { action, ... })
      // We'll use the title as the description if description is not provided, but note: sonner expects the first argument to be the main text.
      // However, we want to show title and description. We can combine them or use the title as the main and description as the second line.
      // Let's do: title as the main, and if description exists, we can put it in the second line or use the action prop?
      // Alternatively, we can use the toast with options:
      //   toast(title, { description: description, action: { label: 'OK', onClick: () => {} } })
      // But note: we don't want an action button necessarily.

      // Since we are using sonner, we can do:
      //   toast(title, { description })
      // And if we want to set the variant (destructive), we can use the `status` option?
      // Looking at sonner docs: we can use `toast.error(title, { description })` for destructive.

      // Let's create a simple mapping:
      if (variant === 'destructive') {
        return toast.error(title, { description });
      } else {
        return toast(title, { description });
      }
    },
  };
};
'use client';

import { useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuthStore } from '@/lib/stores/useAuthStore';

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      useAuthStore.getState().setUserAndSession({
        user: session?.user ?? null,
        session: session ?? null,
      });
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        useAuthStore.getState().setUserAndSession({
          user: session?.user ?? null,
          session: session ?? null,
        });
      }
    );

    // Cleanup subscription on unmount
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return children;
};
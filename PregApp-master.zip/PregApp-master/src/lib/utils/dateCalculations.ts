// Calculate weeks pregnant from a date and due date
export const calculateWeeksPregnant = (dateString: string | null, dueDateString: string | null): number | null => {
  if (!dateString || !dueDateString) return null;
  const date = new Date(dateString);
  const dueDate = new Date(dueDateString);
  const oneWeek = 7 * 24 * 60 * 60 * 1000; // milliseconds in a week
  // LMP is 40 weeks (280 days) before due date
  const LMP = dueDate.getTime() - 40 * oneWeek;
  const weeks = (date.getTime() - LMP) / oneWeek;
  // Return the ceiling of weeks, but not less than 0
  const weeksCeiled = Math.ceil(weeks);
  return weeksCeiled >= 0 ? weeksCeiled : 0;
};

// Format date for display in en-IN locale
export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

// Format time for display
export const formatTime = (dateString: string): string => {
  return new Date(dateString).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

// Calculate days until due date
export const daysUntilDue = (dueDateString: string | null): number | null => {
  if (!dueDateString) return null;
  const dueDate = new Date(dueDateString);
  const today = new Date();
  const diffTime = dueDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};
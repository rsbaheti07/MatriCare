import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface OnboardingState {
  step: number
  formData: {
    dueDate: string | null
    gravida: number | null
    para: number | null
    dietaryPreference: 'veg' | 'non-veg' | 'jain' | null
  }
  isComplete: boolean
  setStep: (step: number) => void
  setFormData: (data: Partial<OnboardingState['formData']>) => void
  setComplete: (complete: boolean) => void
  reset: () => void
}

export const useOnboardingStore = create<OnboardingState>()(
  persist(
    (set) => ({
      step: 1,
      formData: {
        dueDate: null,
        gravida: null,
        para: null,
        dietaryPreference: null,
      },
      isComplete: false,
      setStep: (step) => set({ step }),
      setFormData: (data) => set((state) => ({
        formData: { ...state.formData, ...data },
      })),
      setComplete: (complete) => set({ isComplete: complete }),
      reset: () => set({
        step: 1,
        formData: {
          dueDate: null,
          gravida: null,
          para: null,
          dietaryPreference: null,
        },
        isComplete: false,
      }),
    }),
    {
      name: 'onboarding-storage',
    }
  )
)
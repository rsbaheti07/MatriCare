import { create } from 'zustand'
import { supabase } from '@/lib/supabaseClient'
import type { Session, User } from '@supabase/supabase-js'

interface AuthState {
  user: User | null
  session: Session | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ error: Error | null }>
  loginWithOtp: (phone: string) => Promise<{ error: Error | null }>
  verifyOtp: (phone: string, token: string) => Promise<{ error: Error | null }>
  logout: () => Promise<void>
  clear: () => void
  setUserAndSession: (props: { user: User | null; session: Session | null }) => void
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  session: null,
  isLoading: true,
  login: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    if (error) return { error }
    set({ user: data.user, session: data.session })
    return { error: null }
  },
  loginWithOtp: async (phone: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      phone,
      // Removed emailRedirectTo as it's not needed for phone OTP and may cause issues
    })
    return { error }
  },
  verifyOtp: async (phone: string, token: string) => {
    const { data, error } = await supabase.auth.verifyOtp({
      phone,
      token,
      type: 'sms',
    })
    if (error) return { error }
    set({ user: data.user, session: data.session })
    return { error: null }
  },
  logout: async () => {
    await supabase.auth.signOut()
    set({ user: null, session: null })
  },
  clear: () => set({ user: null, session: null, isLoading: false }),
  setUserAndSession: (props) => set(props),
}))
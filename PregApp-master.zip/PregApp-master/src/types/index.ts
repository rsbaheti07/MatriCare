export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  // Add other profile fields as needed
  created_at: string;
  updated_at: string;
}
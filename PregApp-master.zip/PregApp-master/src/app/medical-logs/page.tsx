'use client';

import { VitalsForm } from '@/features/medical-logs/components/VitalsForm';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function MedicalLogsPage() {
  const { user } = useAuthStore();
  const { toast } = useToast();

  const { data: vitals, isLoading, error } = useQuery({
    queryKey: ['vitals', user?.id],
    queryFn: async () => {
      if (!user) throw new Error('User not authenticated');
      const { data, error } = await supabase
        .from('vitals_logs')
        .select('*')
        .eq('user_id', user.id)
        .order('logged_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading your vitals...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <Card className="p-6">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-destructive">Error Loading Vitals</CardTitle>
          </CardHeader>
          <div className="text-center py-4">
            <p className="text-muted-foreground">{error.message}</p>
            <Button
              variant="outline"
              onClick={() => window.location.reload()}
              className="mt-4"
            >
              Retry
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-2xl font-bold">
          Vitals Tracker
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Track your blood pressure, weight, and blood sugar levels throughout your pregnancy
        </p>
      </div>

      {/* Vitals Form */}
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center space-x-2">
            <Activity className="h-4 w-4 text-primary" />
            Log New Vitals
          </CardTitle>
        </CardHeader>
        <div className="p-6">
          <VitalsForm />
        </div>
      </Card>

      {/* Vitals History */}
      {vitals && vitals.length > 0 ? (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center space-x-2">
                <Activity className="h-4 w-4 text-primary" />
                Vitals History
              </CardTitle>
              <Button variant="outline" size="sm">
                Export Data
              </Button>
            </div>
          </CardHeader>
          <div className="space-y-4 p-6">
            {vitals.map((vital) => (
              <div key={vital.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {new Date(vital.logged_at).toLocaleDateString('en-IN', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </span>
                  <div className="space-x-4 text-left">
                    {vital.systolic_bp !== null && vital.diastolic_bp !== null && (
                      <span className="font-medium">{vital.systolic_bp}/{vital.diastolic_bp} mmHg</span>
                    )}
                    {vital.weight_kg !== null && (
                      <span className="font-medium ml-2">
                        {vital.weight_kg} kg
                      </span>
                    )}
                    {vital.blood_sugar_mgdl !== null && (
                      <span className="font-medium ml-2">
                        {vital.blood_sugar_mgdl} mg/dL
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ) : (
        <Card className="p-8 text-center">
          <CardTitle className="text-lg font-semibold">No vitals logged yet</CardTitle>
          <p className="text-muted-foreground mt-2">
            Start tracking your vitals to see trends and insights throughout your pregnancy journey.
          </p>
        </Card>
      )}
    </div>
  );
}
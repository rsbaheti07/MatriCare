"use client";
import { useBumpReminder } from '@/features/bump/hooks/useBumpReminder';
import { PhotoCapture } from '@/features/bump/components/PhotoCapture';
import { BumpGallery } from '@/features/bump/components/BumpGallery';
import { VideoGenerator } from '@/features/bump/components/VideoGenerator';

export default function BumpPage() {
  const showReminder = useBumpReminder();

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Bump Timeline</h1>

      {/* Weekly Reminder Banner */}
      {showReminder && (
        <div className="mb-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
          <div className="flex items-center space-x-3">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3" />
            </svg>
            <div>
              <h3 className="font-medium text-primary">Time for your weekly bump photo!</h3>
              <p className="text-sm text-muted-foreground">
                Capture your bump progression this week to build your timelapse video.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-6">
        <PhotoCapture />
        <BumpGallery />
        <VideoGenerator />
      </div>
    </div>
  );
}
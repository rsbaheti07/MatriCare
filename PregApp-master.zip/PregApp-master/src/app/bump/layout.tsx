'use client';

import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function BumpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user } = useAuthStore();
  const { isComplete } = useOnboardingStore();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }

    if (!isComplete) {
      router.push('/onboarding');
      return;
    }
  }, [user, isComplete, router]);

  return (
    <div>
      {children}
    </div>
  );
}
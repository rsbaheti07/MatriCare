'use client';

import { OnboardingFlow } from '@/features/onboarding/components/OnboardingFlow';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function OnboardingPage() {
  const { isComplete } = useOnboardingStore();
  const router = useRouter();

  useEffect(() => {
    if (isComplete) {
      // Redirect to dashboard if onboarding is complete
      router.push('/dashboard');
    }
  }, [isComplete, router]);

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
      <OnboardingFlow />
    </div>
  );
}
'use client';

import { ProgressBar } from '@/features/hospital-checklist/components/ProgressBar';
import { ChecklistCategory } from '@/features/hospital-checklist/components/ChecklistCategory';
import { getChecklistCategories } from '@/features/hospital-checklist/utils/checklistItems';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { CalendarDays, CheckCircle2, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { calculateWeeksPregnant, daysUntilDue } from '@/lib/utils/dateCalculations';

export default function HospitalChecklistPage() {
  const { user } = useAuthStore();
  const { isComplete } = useOnboardingStore();
  const { toast } = useToast();
  const router = useRouter();

  // Redirect if not authenticated or onboarding not complete
  useEffect(() => {
    if (!user) {
      router.push('/login');
      return;
    }

    if (!isComplete) {
      router.push('/onboarding');
      return;
    }
  }, [user, isComplete, router]);

  // Get due date from onboarding store to determine when to show the checklist
  const { formData } = useOnboardingStore();

  // Calculate weeks pregnant and days until using utility functions
  const weeksPregnant = calculateWeeksPregnant(new Date().toISOString(), formData.dueDate);
  const daysUntilDueVal = daysUntilDue(formData.dueDate);

  // Determine if we should show the checklist (within 4 weeks of due date)
  const showChecklist = daysUntilDueVal !== null && daysUntilDueVal <= 28 && daysUntilDueVal >= 0; // Within 4 weeks (28 days) and not past due

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-2xl font-bold">
          Hospital Bag Checklist
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Get ready for your big day with our comprehensive hospital bag checklist
        </p>
      </div>

      {/* Due Date Banner */}
      {formData.dueDate !== null && daysUntilDueVal !== null && (
        <div
          className={[
            'p-4 mb-4 rounded-lg text-center font-medium',
            daysUntilDueVal < 0 ? 'bg-destructive/20 text-destructive' :
            daysUntilDueVal <= 7 ? 'bg-primary/20 text-primary' :
            daysUntilDueVal <= 14 ? 'bg-accent/20 text-accent' :
            'bg-muted/20 text-muted-foreground'
          ].join(' ')}
        >
          {daysUntilDueVal < 0 ? (
            <>
              <CheckCircle2 className="mr-2 h-4 w-4" />
              Your due date was {(-daysUntilDueVal)} day(s) ago
            </>
          ) : (
            <>
              <CalendarDays className="mr-2 h-4 w-4" />
              {daysUntilDueVal === 0 ? 'Today is your due date!' : ('Due in ' + daysUntilDueVal + ' day(s)')}
            </>
          )}
        </div>
      )}

      {/* Show reminder to start checklist 4 weeks before due date */}
      {formData.dueDate !== null && daysUntilDueVal !== null && daysUntilDueVal > 28 && daysUntilDueVal <= 42 && (
        <div className="p-4 mb-4 rounded-lg bg-primary/20 text-primary text-center">
          <CalendarDays className="mr-2 h-4 w-4" />
          Start planning your hospital bag! Your due date is in {daysUntilDueVal} days.
        </div>
      )}

      {/* Main Checklist Content */}
      {showChecklist ? (
        <>
          {/* Progress Bar */}
          <Card className="p-6">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Packing Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ProgressBar />
            </CardContent>
          </Card>

          {/* Checklist Categories */}
          <div className="space-y-6">
            {getChecklistCategories().map((category) => (
              <ChecklistCategory key={category} category={category} />
            ))}
          </div>
        </>
      ) : (
        // Show message if not yet time to start checklist or if past due date
        formData.dueDate === null ? (
          <Card className="p-8 text-center">
            <CardTitle className="text-lg font-semibold">Complete Onboarding</CardTitle>
            <p className="text-muted-foreground mt-2">
              Please complete the onboarding process to set your due date and access the hospital bag checklist.
            </p>
          </Card>
        ) : daysUntilDueVal! < 0 ? (
          <Card className="p-8 text-center">
            <CardTitle className="text-lg font-semibold">Your Due Date Has Passed</CardTitle>
            <p className="text-muted-foreground mt-2">
              Your due date was {(-daysUntilDueVal!)} day(s) ago.
              You can still use the checklist if needed, but it's primarily designed for the weeks leading up to your due date.
            </p>
            <div className="mt-4">
              <button
                onClick={() => {
                  // Force show checklist even if past due date
                  // We'll need to modify the showChecklist condition or provide a way to override
                  // For now, we'll just show a message that they can still use it
                }}
                className="btn btn-outline btn-sm"
              >
                View Checklist Anyway
              </button>
            </div>
          </Card>
        ) : (
          <Card className="p-8 text-center">
            <CardTitle className="text-lg font-semibold">Not Yet Time to Start</CardTitle>
            <p className="text-muted-foreground mt-2">
              The hospital bag checklist will become available 4 weeks before your due date.
              Currently, you are {weeksPregnant} weeks pregnant ({daysUntilDueVal} days until due).
              Please check back closer to your due date.
            </p>
          </Card>
        )
      )}
    </div>
  );
}
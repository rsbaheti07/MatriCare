'use client';

import { PostList } from '@/features/community/components/PostList';
import { NewPostForm } from '@/features/community/components/NewPostForm';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Users, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export default function CommunityPage() {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const { data: allPosts, isLoading, error } = useQuery({
    queryKey: ['posts'],
    queryFn: async () => {
      // We'll fetch posts from the community_posts table
      // For now, we'll join with profiles to get user info
      const { data, error } = await supabase
        .from('community_posts')
        .select(`
          *,
          tags,
          profiles!inner (
            full_name,
            avatar_url
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  // Filter posts by selected tags (client-side filtering for simplicity)
  const posts = allPosts?.filter(post => {
    if (selectedTags.length === 0) return true;
    if (!post.tags || post.tags.length === 0) return false;
    return selectedTags.some(tag => post.tags?.includes(tag));
  }) || [];

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading community posts...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <Card className="p-6">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-destructive">Error Loading Community</CardTitle>
          </CardHeader>
          <div className="text-center py-4">
            <p className="text-muted-foreground">{error.message}</p>
            <Button
              variant="outline"
              onClick={() => window.location.reload()}
              className="mt-4"
            >
              Retry
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-2xl font-bold">
          The Village Community
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Connect with other moms-to-be, share experiences, and find support throughout your pregnancy journey
        </p>
      </div>

      {/* New Post Form */}
      {user && (
        <Card className="w-full max-w-xl">
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center space-x-2">
              <Users className="h-4 w-4 text-primary" />
              Share with the Community
            </CardTitle>
          </CardHeader>
          <div className="p-6">
            <NewPostForm />
          </div>
        </Card>
      )}

      {/* Tag Filter */}
      {selectedTags.length > 0 && (
        <Card className="p-4 mb-4">
          <CardHeader className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">
              Filtered by: {selectedTags.map(tag => `#${tag}`).join(' ')}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedTags([])}
            >
              Clear Filter
            </Button>
          </CardHeader>
        </Card>
      )}

      {/* Tag Filters */}
      <Card className="p-4">
        <CardHeader className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">
            Filter by Tags
          </span>
          {selectedTags.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedTags([])}
            >
              Clear All
            </Button>
          )}
        </CardHeader>
        <CardContent className="flex flex-wrap space-x-2 mt-2">
          {/* Show some common pregnancy tags as quick filters */}
          <div className="flex flex-wrap space-x-1">
            {[
              'Nutrition',
              'Exercise',
              'Morning Sickness',
              'Doctor Visits',
              'Ultrasound',
              'Birth Planning',
              'Breastfeeding',
              'Mental Health'
            ].map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  setSelectedTags(prev =>
                    prev.includes(tag)
                      ? prev.filter(t => t !== tag)
                      : [...prev, tag]
                  );
                }}
                className={cn(
                  "px-3 py-1.5 text-xs rounded border",
                  selectedTags.includes(tag)
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted hover:bg-muted/50"
                )}
              >
                #{tag}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Show active filters */}
      {selectedTags.length > 0 && (
        <Card className="p-4 mb-4">
          <CardHeader className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">
              Filtered by: {selectedTags.map(tag => `#${tag}`).join(' ')}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedTags([])}
            >
              Clear Filter
            </Button>
          </CardHeader>
        </Card>
      )}

      {/* Posts List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center space-x-2">
              <Plus className="h-4 w-4 text-primary" />
              Recent Posts
            </CardTitle>
            {user && (
              <Button variant="outline" size="sm" asChild>
                Create New Post
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <PostList posts={posts || []} />
        </CardContent>
      </Card>
    </div>
  );
}
'use client';

import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user } = useAuthStore();
  const { isComplete } = useOnboardingStore();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      // Redirect to login if not authenticated
      router.push('/login');
      return;
    }

    if (!isComplete) {
      // Redirect to onboarding if not completed
      router.push('/onboarding');
      return;
    }
  }, [user, isComplete, router]);

  return (
    <div>
      {children}
    </div>
  );
}
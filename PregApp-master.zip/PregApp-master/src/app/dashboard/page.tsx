'use client';

import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { supabase } from '@/lib/supabaseClient';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { TrendingUp, Activity, Users, MessageSquare } from 'lucide-react';
import { calculateWeeksPregnant, daysUntilDue } from '@/lib/utils/dateCalculations';
import type { Profile } from '@/types';

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { formData, isComplete } = useOnboardingStore();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [weeksPregnant, setWeeksPregnant] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        setProfile(data);
      } catch (err) {
        console.error('Error fetching profile:', err);
        // We'll still show the dashboard even if profile fetch fails
      } finally {
        setLoading(false);
      }
    };

    const calculateWeek = () => {
      const weeks = calculateWeeksPregnant(new Date().toISOString(), formData.dueDate);
      setWeeksPregnant(weeks);
    };

    fetchProfile();
    calculateWeek();
  }, [user, formData.dueDate]);

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <Card className="space-y-4">
        <CardHeader className="flex items-center justify-between">
          <div className="space-y-2">
            <CardTitle className="text-2xl font-bold">
              Welcome back, {profile?.full_name ?? user?.email?.split('@')[0] ?? 'Mom-to-be'}!
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Here's your pregnancy overview
            </CardDescription>
          </div>
          {weeksPregnant !== null && (
            <div className="text-center">
              <p className="text-sm font-medium text-muted-foreground">Week of Pregnancy</p>
              <p className="text-3xl font-bold text-primary">{weeksPregnant}</p>
            </div>
          )}
        </CardHeader>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Stat 1: Vitals Logged */}
        <Card className="p-4">
          <CardHeader className="flex items-center space-x-3">
            <Activity className="h-5 w-5 text-primary" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Vitals Logged</p>
              <p className="text-lg font-semibold">0</p>
            </div>
          </CardHeader>
        </Card>

        {/* Stat 2: Appointments */}
        <Card className="p-4">
          <CardHeader className="flex items-center space-x-3">
            <Users className="h-5 w-5 text-primary" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Appointments</p>
              <p className="text-lg font-semibold">0</p>
            </div>
          </CardHeader>
        </Card>

        {/* Stat 3: Community Posts */}
        <Card className="p-4">
          <CardHeader className="flex items-center space-x-3">
            <MessageSquare className="h-5 w-5 text-primary" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Community Posts</p>
              <p className="text-lg font-semibold">0</p>
            </div>
          </CardHeader>
        </Card>

        {/* Stat 4: Days Until Due */}
        <Card className="p-4">
          <CardHeader className="flex items-center space-x-3">
            <TrendingUp className="h-5 w-5 text-primary" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Days Until Due</p>
              {formData.dueDate ? (
                <p className="text-lg font-semibold">
                  {(() => {
                    const days = daysUntilDue(formData.dueDate);
                    return days !== null && days > 0 ? days : 0;
                  })()}
                </p>
              ) : (
                <p className="text-lg font-semibold">--</p>
              )}
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
          <CardDescription className="text-muted-foreground mt-2">
            Common tasks to get you started
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 mt-4">
          <Button
            variant="outline"
            asChild
            className="w-full flex items-center justify-start space-x-3 p-4"
          >
            <Activity className="h-4 w-4 text-primary" />
            <div className="space-y-1 text-left">
              <span className="font-medium">Log Vitals</span>
              <span className="text-sm text-muted-foreground">Track your blood pressure, weight, and more</span>
            </div>
          </Button>
          <Button
            variant="outline"
            asChild
            className="w-full flex items-center justify-start space-x-3 p-4"
          >
            <Users className="h-4 w-4 text-primary" />
            <div className="space-y-1 text-left">
              <span className="font-medium">Join Community</span>
              <span className="text-sm text-muted-foreground">Connect with other moms-to-be</span>
            </div>
          </Button>
          <Button
            variant="outline"
            asChild
            className="w-full flex items-center justify-start space-x-3 p-4"
          >
            <MessageSquare className="h-4 w-4 text-primary" />
            <div className="space-y-1 text-left">
              <span className="font-medium">Read Articles</span>
              <span className="text-sm text-muted-foreground">Get expert pregnancy advice</span>
            </div>
          </Button>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
            <Button variant="outline" size="sm">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Placeholder for recent activity items */}
          <div className="text-center py-8">
            <p className="text-muted-foreground">No recent activity yet</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
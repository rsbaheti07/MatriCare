'use client';

import { InvitePartnerForm } from '@/features/partner-sync/components/InvitePartnerForm';
import { PartnerAcceptForm } from '@/features/partner-sync/components/PartnerAcceptForm';
import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Mail, Users, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { Suspense } from 'react';

export default function PartnerSyncPage() {
  const { user } = useAuthStore();
  const [inviteCode, setInviteCode] = useState('');
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    setInviteCode(searchParams.get('code') ?? '');
  }, []);

  const router = useRouter();

  // Check if we have an invite code in the URL (for accepting invites)

  // Fetch existing partner connections
  const [partnerConnections, setPartnerConnections] = useState<any[]>([]);
  const [pendingInvites, setPendingInvites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPartnerData = async () => {
      if (!user) return;

      try {
        // Fetch sent invites (where user is the inviter)
        const { data: sentData, error: sentError } = await supabase
          .from('partner_invites')
          .select('*')
          .eq('inviter_id', user.id)
          .order('created_at', { ascending: false });

        if (sentError) throw sentError;

        // Fetch received invites (where user is the partner)
        const { data: receivedData, error: receivedError } = await supabase
          .from('partner_invites')
          .select('*')
          .eq('partner_id', user.id)
          .order('created_at', { ascending: false });

        if (receivedError) throw receivedError;

        setPartnerConnections(receivedData.filter((inv: any) => inv.status === 'accepted'));
        setPendingInvites(sentData.filter((inv: any) => inv.status === 'pending'));
      } catch (err) {
        console.error('Error fetching partner data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPartnerData();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  const content = inviteCode ? (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Accept Partner Invitation</CardTitle>
          <CardDescription className="text-muted-foreground">
            Enter the invite code you received to connect with your partner
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <PartnerAcceptForm inviteCode={inviteCode} />
        </CardContent>
      </Card>
    </div>
  ) : (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-2xl font-bold">
          Partner Sync
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Connect with your partner to share your pregnancy journey, appointments, and important updates
        </p>
      </div>

      {/* Invite Partner Section */}
      <Card className="w-full max-w-xl">
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center space-x-2">
            <Users className="h-4 w-4 text-primary" />
            Invite Your Partner
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <p className="text-muted-foreground mb-4">
            Send an invitation to your partner so they can follow along with your pregnancy journey.
            They'll receive an email with a unique code to connect their account.
          </p>
          <InvitePartnerForm />
        </CardContent>
      </Card>

      {/* Pending Invites Section */}
      {pendingInvites.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center space-x-2">
                <Mail className="h-4 w-4 text-primary" />
                Pending Invitations
              </CardTitle>
              <Button variant="outline" size="sm">
                Refresh
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-4 space-y-3">
            {pendingInvites.map((invite) => (
              <div key={invite.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="font-medium">{invite.partner_name || 'Someone'}</p>
                    <p className="text-sm text-muted-foreground">
                      {invite.partner_email}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Sent: {new Date(invite.created_at).toLocaleDateString('en-IN')}
                    </p>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Expires: {new Date(invite.expires_at).toLocaleDateString('en-IN')}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Connected Partners Section */}
      {partnerConnections.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Connected Partners
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-4 space-y-3">
            {partnerConnections.map((partner) => (
              <div key={partner.id} className="border rounded-lg p-4">
                <div className="flex items-center space-x-3">
                  {partner.user_avatar_url ? (
                    <img
                      src={partner.user_avatar_url}
                      alt="Partner avatar"
                      className="h-10 w-10 rounded-full"
                    />
                  ) : (
                    <div className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                      <Users className="h-5 w-5" />
                    </div>
                  )}
                  <div className="space-y-1">
                    <p className="font-medium">{partner.full_name || 'Partner'}</p>
                    <p className="text-sm text-muted-foreground">
                      Connected since: {new Date(partner.accepted_at).toLocaleDateString('en-IN')}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Empty states */}
      {pendingInvites.length === 0 && partnerConnections.length === 0 && (
        <Card className="p-8 text-center">
          <CardTitle className="text-lg font-semibold">No partner connections yet</CardTitle>
          <p className="text-muted-foreground mt-2">
            Invite your partner to join you on this journey. They'll be able to see your updates,
            appointments, and share in the excitement.
          </p>
        </Card>
      )}
    </div>
  );

  return (
    <Suspense fallback={null}>
      {content}
    </Suspense>
  );
}
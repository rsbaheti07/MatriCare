'use client';

import { useAuthStore } from '@/lib/stores/useAuthStore';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { Phone } from 'lucide-react';
import { Mail } from 'lucide-react';

export default function LoginPage() {
  const { login, loginWithOtp, verifyOtp } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'email' | 'otp' | 'phone'>('email');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await login(email, password);
      if (result.error) throw result.error;
      setSuccess('Login successful!');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await loginWithOtp(phone);
      if (result.error) throw result.error;
      setStep('otp');
      setSuccess('OTP sent to your phone!');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await verifyOtp(phone, otp);
      if (result.error) throw result.error;
      setSuccess('Phone verified successfully!');
      setTimeout(() => {
        setStep('email');
        setPhone('');
        setOtp('');
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Welcome to MatriCare</CardTitle>
          <CardDescription className="text-muted-foreground">
            Sign in to continue your pregnancy journey
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 'email' && (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">Email</div>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">Password</div>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                />
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
              {success && (
                <p className="text-sm text-primary">{success}</p>
              )}
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? 'Signing in...' : 'Sign in'}
              </Button>
              <div className="text-center text-sm">
                <p>Don't have an account? Signing up creates one automatically.</p>
                <button
                  type="button"
                  onClick={() => setStep('phone')}
                  className="underline text-sm text-primary hover:text-primary/90"
                >
                  Continue with Phone
                </button>
              </div>
            </form>
          )}
          {step === 'phone' && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">Phone Number</div>
                <div className="flex items-center space-x-2">
                  <span className="text-muted-foreground">+91</span>
                  <Input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    required
                    maxLength={10}
                    placeholder="Enter 10-digit mobile number"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  We'll send an OTP to this number for verification
                </p>
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
              {success && (
                <p className="text-sm text-primary">{success}</p>
              )}
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? 'Sending OTP...' : 'Send OTP'}
              </Button>
              <div className="text-center text-sm">
                <button
                  type="button"
                  onClick={() => setStep('email')}
                  className="underline text-sm text-primary hover:text-primary/90"
                >
                  Back to Email
                </button>
              </div>
            </form>
          )}
          {step === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">
                  Enter OTP sent to +91 {phone.slice(0, 5)}****{phone.slice(-2)}
                </div>
                <Input
                  type="text"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  required
                  maxLength={6}
                  autoComplete="otp"
                />
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
              {success && (
                <p className="text-sm text-primary">{success}</p>
              )}
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? 'Verifying...' : 'Verify OTP'}
              </Button>
              <div className="text-center text-sm">
                <button
                  type="button"
                  onClick={() => setStep('phone')}
                  className="underline text-sm text-primary hover:text-primary/90"
                >
                  Change Number
                </button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
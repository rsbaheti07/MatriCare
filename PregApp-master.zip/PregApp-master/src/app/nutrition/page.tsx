'use client';

import { useAuthStore } from '@/lib/stores/useAuthStore';
import { useOnboardingStore } from '@/lib/stores/useOnboardingStore';
import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { LineChart, Line, XAxis as LineXAxis, YAxis as LineYAxis, CartesianGrid as LineCartesianGrid, Tooltip as LineTooltip, Legend as LineLegend } from 'recharts';
import { PieChart, Pie, Cell, Tooltip as PieTooltip, Legend as PieLegend } from 'recharts';
import { supabase } from '@/lib/supabaseClient';
import { getUserNutritionContext, prepareNutrientComparisonData, prepareWeightProgressionData, prepareMacronutrientData } from '@/features/nutrition/utils/chartData';
import { getNutritionRecommendations } from '@/features/nutrition/utils/nutritionCalculations';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export default function NutritionPage() {
  const { user } = useAuthStore();
  const { formData, isComplete } = useOnboardingStore();
  const { toast } = useToast();

  const [week, setWeek] = useState<number | null>(null);
  const [dietaryType, setDietaryType] = useState<'veg' | 'non-veg' | 'jain' | null>(null);
  const [nutritionData, setNutritionData] = useState<any>(null);
  const [weightData, setWeightData] = useState<any[]>([]);
  const [macroData, setMacroData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadNutritionData = async () => {
      if (!user) {
        setError('Please log in to view nutrition charts');
        setIsLoading(false);
        return;
      }

      if (!isComplete) {
        setError('Please complete onboarding to access nutrition charts');
        setIsLoading(false);
        return;
      }

      try {
        // Get week and dietary type from user data
        const { week: w, dietaryType: dt } = await getUserNutritionContext();
        setWeek(w);
        setDietaryType(dt);

        if (w === null) {
          setError('Unable to calculate pregnancy week. Please check your due date in onboarding.');
          setIsLoading(false);
          return;
        }

        // Get nutrition recommendations for the current week and dietary type
        const recommendations = getNutritionRecommendations(w, dt);
        // Prepare data for nutrient comparison bar chart (intake vs recommended)
        // For now, we'll use placeholder intake values (would come from food log in future)
        const nutrientChartData = prepareNutrientComparisonData(w, dt);
        setNutritionData(nutrientChartData);

        // Fetch weight progression data from vitals_logs
        const weightChartData = await prepareWeightProgressionData(user.id);
        setWeightData(weightChartData);

        // Prepare macronutrient pie chart data
        const macroChartData = prepareMacronutrientData(w, dt);
        setMacroData(macroChartData);

        setIsLoading(false);
      } catch (err: any) {
        setError(err.message);
        setIsLoading(false);
      }
    };

    loadNutritionData();
  }, [user, isComplete]);

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading your nutrition charts...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <Card className="p-6">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-destructive">Error Loading Nutrition Data</CardTitle>
          </CardHeader>
          <div className="text-center py-4">
            <p className="text-muted-foreground">{error}</p>
          </div>
        </Card>
      </div>
    );
  }

  if (week === null || dietaryType === null) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-8">
        <Card className="p-6 text-center">
          <CardTitle className="text-lg font-bold">Set Up Your Profile</CardTitle>
          <p className="text-muted-foreground mt-2">
            Please complete the onboarding process to set your due date and dietary preferences.
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-2xl font-bold">
          Nutrition Charts
        </h1>
        <p className="text-muted-foreground text-center max-w-md">
          Track your nutritional needs and progress throughout your pregnancy
        </p>
        <div className="text-sm text-muted-foreground">
          Week {week} of pregnancy • {dietaryType.charAt(0).toUpperCase() + dietaryType.slice(1)} diet
        </div>
      </div>

      {/* Nutrient Intake vs Recommendations Bar Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center space-x-2">
            <span className="text-primary">🥗</span>
            Nutrient Intake vs Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={nutritionData}
              margin={{ top: 20, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => `${value}`} />
              <Legend verticalAlign="top" height={36} />
              <Bar dataKey="intake" fill="#8884d8" radius={[6, 6, 0, 0]} />
              <Bar dataKey="recommended" fill="#82ca9d" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 text-xs text-muted-foreground">
            Intake values are placeholders. In a future update, you'll be able to log your meals to see actual intake.
          </div>
        </CardContent>
      </Card>

      {/* Weight Progression Line Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center space-x-2">
            <span className="text-primary">⚖️</span>
            Weight Progression
          </CardTitle>
        </CardHeader>
        <CardContent>
          {weightData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart
                data={weightData}
                margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <LineXAxis dataKey="date" tick={{ fontSize: 12 }} />
                <LineYAxis orientation="left" tick={{ fontSize: 12 }} domain={['dataMin', 'dataMax']}>
                  <LineYAxis tickFormatter={(value) => `${value} kg`} />
                </LineYAxis>
                <LineTooltip formatter={(value) => `${value} kg`} />
                <Legend verticalAlign="top" height={36} />
                <Line type="monotone" dataKey="weight" stroke="#8884d8" strokeWidth={2} />
                {/* Optional: dots on the line */}
                {/* <Line type="monotone" dataKey="weight" stroke="#8884d8" strokeWidth={2}> */}
                {/*   <Dot /> */}
                {/* </Line> */}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="p-8 text-center">
              <p className="text-muted-foreground">No weight data available yet. Start logging your vitals to see your weight progression.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Macronutrient Breakdown Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center space-x-2">
            <span className="text-primary">🥧</span>
            Macronutrient Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={macroData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                labelLine={false}
                label={({ name, value, percent }) => (
                  <div>
                    {name}: {Math.round(percent ?? 0)}%
                  </div>
                )}
              >
                {macroData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={['#8884d8', '#82ca9d', '#ffc658'][index]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 text-xs text-muted-foreground">
            Based on recommended calorie intake for your week and dietary type.
          </div>
        </CardContent>
      </Card>

      {/* Nutritional Recommendations Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Daily Nutritional Recommendations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <p className="font-medium">Calories: {getNutritionRecommendations(week, dietaryType).calories} kcal</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium">Protein: {getNutritionRecommendations(week, dietaryType).protein} g</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium">Calcium: {getNutritionRecommendations(week, dietaryType).calcium} mg</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium">Iron: {getNutritionRecommendations(week, dietaryType).iron} mg</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium">Folic Acid: {getNutritionRecommendations(week, dietaryType).folicAcid} mcg</p>
          </div>
        </CardContent>
        <CardFooter className="pt-4">
          <p className="text-xs text-muted-foreground">
            These are general guidelines. Consult with your healthcare provider for personalized advice.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
import * as React from "react"
import * as DialogPrimitive from "@radix-ui/react-dialog"
import { cn } from "@/lib/utils"

const Dialog = DialogPrimitive.Root
const DialogTrigger = DialogPrimitive.Trigger
const DialogContent = DialogPrimitive.Content
const DialogHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn("flex flex-col space-y-1.5 p-6", className)}
      {...props}
    />
  )
})
const DialogTitle = DialogPrimitive.Title
const DialogDescription = DialogPrimitive.Description
const DialogFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn("flex flex-col-reverse sm:flex-row sm:space-x-2 sm:space-y-0 p-6", className)}
      {...props}
    />
  )
})
const DialogOverlay = DialogPrimitive.Overlay

interface ModalProps extends React.ComponentPropsWithoutRef<typeof Dialog> {
  /**
   * Whether the modal should have a glassmorphism effect
   */
  glass?: boolean
  /**
   * Whether the modal should have a shadow
   */
  shadow?: boolean
  /**
   * Optional className to override or extend the default styles
   */
  className?: string
}

const Modal = React.forwardRef<HTMLDivElement, ModalProps>(({ className, glass, shadow, ...props }, ref) => {
  return (
    <div ref={ref} className={cn(className)}>
      <Dialog {...props}>
        <DialogOverlay className="bg-black/80 dark:bg-black/60" />
        <DialogContent
          className={cn(
            "relative max-h-[85vh] w-full max-w-lg overflow-hidden rounded-lg border bg-background text-foreground shadow-lg ring-offset-background/50",
            glass && "glass",
            shadow && "shadow-2xl",
          )}
        >
          <DialogHeader className="flex flex-col space-y-1.5 p-6">
            <DialogTitle className="text-lg font-semibold leading-none tracking-tight" />
            <DialogDescription className="text-sm text-muted-foreground" />
          </DialogHeader>
          <div className="p-6 pt-0">
            <slot />
          </div>
          <DialogFooter className="flex flex-col-reverse sm:flex-row sm:space-x-2 sm:space-y-0 p-6">
            <slot name="footer" />
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
})
Modal.displayName = DialogPrimitive.Root.displayName

interface ModalTriggerProps extends React.ComponentPropsWithoutRef<typeof DialogTrigger> {}
const ModalTrigger = React.forwardRef<
  HTMLButtonElement,
  ModalTriggerProps
>(({ className, ...props }, ref) => {
  return (
    <DialogTrigger
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90",
        className
      )}
      {...props}
    />
  );
});
ModalTrigger.displayName = DialogPrimitive.Trigger.displayName

// We re-export the primitive components for flexibility
export {
  Modal,
  ModalTrigger,
  DialogOverlay as ModalOverlay,
  DialogContent as ModalContent,
  DialogHeader as ModalHeader,
  DialogTitle as ModalTitle,
  DialogDescription as ModalDescription,
  DialogFooter as ModalFooter,
}
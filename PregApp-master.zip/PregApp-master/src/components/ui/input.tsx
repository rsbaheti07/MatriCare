import * as React from "react"
import { cn } from "@/lib/utils"

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /**
   * Whether the input should have an outline style
   */
  outline?: boolean
  /**
   * Whether the input should be ghost (transparent background)
   */
  ghost?: boolean
  /**
   * Whether the input should have a glassmorphism effect
   */
  glass?: boolean
}

const Input = React.forwardRef<
  HTMLInputElement,
  InputProps
>(({ className, type, outline, ghost, glass, ...props }, ref) => {
  return (
    <input
      type={type ?? "text"}
      ref={ref}
      className={cn(
        "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
        outline && "border-input hover:bg-accent",
        ghost && "bg-transparent hover:bg-accent/5",
        glass && "glass",
        className
      )}
      {...props}
    />
  )
})
Input.displayName = "Input"

export { Input }